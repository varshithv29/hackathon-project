"""
Main application entry point for the Attendance Monitoring System
"""

import os
from app import create_app, socketio
from flask_migrate import upgrade
from app.models import db, User, Student, Faculty, Course, Enrollment

app = create_app()

@app.shell_context_processor
def make_shell_context():
    return {
        'db': db,
        'User': User,
        'Student': Student,
        'Faculty': Faculty,
        'Course': Course,
        'Enrollment': Enrollment
    }

@app.cli.command()
def init_db():
    """Initialize the database with sample data"""
    with app.app_context():
        db.create_all()
        
        # Create admin user
        admin_user = User(
            username='admin',
            email='admin@college.edu',
            role='admin'
        )
        admin_user.set_password('admin123')
        db.session.add(admin_user)
        
        # Create sample faculty
        faculty_user = User(
            username='faculty1',
            email='faculty1@college.edu',
            role='faculty'
        )
        faculty_user.set_password('admin123')
        db.session.add(faculty_user)
        
        db.session.commit()
        
        # Create faculty profile
        faculty = Faculty(
            user_id=faculty_user.id,
            faculty_id='FAC001',
            first_name='Dr. John',
            last_name='Smith',
            department='Computer Science',
            designation='Professor',
            phone='+1234567890',
            email='faculty1@college.edu'
        )
        db.session.add(faculty)
        
        # Create sample course
        course = Course(
            course_code='CS101',
            course_name='Introduction to Computer Science',
            department='Computer Science',
            credits=3,
            faculty_id=faculty.id,
            year=2024,
            semester=1,
            description='Basic concepts of computer science'
        )
        db.session.add(course)
        
        # Create sample students
        for i in range(1, 6):
            student_user = User(
                username=f'student{i}',
                email=f'student{i}@college.edu',
                role='student'
            )
            student_user.set_password('admin123')
            db.session.add(student_user)
            db.session.commit()
            
            student = Student(
                user_id=student_user.id,
                student_id=f'STU{i:03d}',
                first_name=f'Student{i}',
                last_name='LastName',
                department='Computer Science',
                year=1,
                semester=1,
                phone='+1234567890'
            )
            db.session.add(student)
            
            # Enroll student in course
            enrollment = Enrollment(
                student_id=student.id,
                course_id=course.id,
                status='active'
            )
            db.session.add(enrollment)
        
        db.session.commit()
        print("Database initialized with sample data!")
        print("Default login credentials:")
        print("Admin: username=admin, password=admin123")
        print("Faculty: username=faculty1, password=admin123")
        print("Student: username=student1, password=admin123")

if __name__ == '__main__':
    # Create necessary directories
    os.makedirs('face_encodings', exist_ok=True)
    os.makedirs('uploads', exist_ok=True)
    os.makedirs('logs', exist_ok=True)
    
    # Run the application
    socketio.run(app, debug=True, host='0.0.0.0', port=5000, allow_unsafe_werkzeug=True)
