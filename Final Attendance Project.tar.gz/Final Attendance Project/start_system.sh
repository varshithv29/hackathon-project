#!/bin/bash

echo "🚀 Starting Automated Student Attendance Monitoring System..."
echo ""

# Navigate to project directory
cd /Users/varshithvijay/attendance-monitoring-system

# Activate virtual environment
echo "📦 Activating virtual environment..."
source venv/bin/activate

# Start the application
echo "🌟 Starting Flask application..."
echo ""
echo "✅ System will be available at: http://localhost:8000"
echo "📋 Login Credentials:"
echo "   👨‍💼 Admin:    username=admin,    password=admin123"
echo "   👨‍🏫 Faculty:  username=faculty1,  password=admin123"
echo "   👨‍🎓 Students: username=student1-5, password=admin123"
echo ""
echo "🔍 Press Ctrl+C to stop the system"
echo ""

python3 FINAL_ATTENDANCE_SYSTEM.py
