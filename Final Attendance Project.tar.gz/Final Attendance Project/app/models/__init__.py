from app import db

class UserMixin:
    id = db.Column(db.Integer, primary_key=True)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())
    updated_at = db.Column(db.DateTime, default=db.func.current_timestamp(), onupdate=db.func.current_timestamp())

class User(db.Model, UserMixin):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # 'student', 'faculty', 'admin'
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())
    updated_at = db.Column(db.DateTime, default=db.func.current_timestamp(), onupdate=db.func.current_timestamp())
    
    # Relationships
    student_profile = db.relationship('Student', backref='user', uselist=False, cascade='all, delete-orphan')
    faculty_profile = db.relationship('Faculty', backref='user', uselist=False, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<User {self.username}>'

class Student(db.Model, UserMixin):
    __tablename__ = 'students'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    student_id = db.Column(db.String(20), unique=True, nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    date_of_birth = db.Column(db.Date)
    phone = db.Column(db.String(15))
    address = db.Column(db.Text)
    department = db.Column(db.String(100), nullable=False)
    year = db.Column(db.Integer, nullable=False)  # 1, 2, 3, 4
    semester = db.Column(db.Integer, nullable=False)  # 1, 2
    face_encoding = db.Column(db.Text)  # Store face encoding as JSON string
    profile_image = db.Column(db.String(255))
    emergency_contact = db.Column(db.String(15))
    parent_phone = db.Column(db.String(15))
    
    # Relationships
    attendances = db.relationship('Attendance', backref='student', lazy='dynamic')
    enrollments = db.relationship('Enrollment', backref='student', lazy='dynamic')
    
    def __repr__(self):
        return f'<Student {self.student_id}: {self.first_name} {self.last_name}>'

class Faculty(db.Model, UserMixin):
    __tablename__ = 'faculty'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    faculty_id = db.Column(db.String(20), unique=True, nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    department = db.Column(db.String(100), nullable=False)
    designation = db.Column(db.String(50))  # Professor, Assistant Professor, etc.
    phone = db.Column(db.String(15))
    email = db.Column(db.String(120))
    office_location = db.Column(db.String(100))
    
    # Relationships
    courses = db.relationship('Course', backref='faculty', lazy='dynamic')
    
    def __repr__(self):
        return f'<Faculty {self.faculty_id}: {self.first_name} {self.last_name}>'

class Course(db.Model, UserMixin):
    __tablename__ = 'courses'
    
    id = db.Column(db.Integer, primary_key=True)
    course_code = db.Column(db.String(20), unique=True, nullable=False)
    course_name = db.Column(db.String(200), nullable=False)
    department = db.Column(db.String(100), nullable=False)
    credits = db.Column(db.Integer, nullable=False)
    faculty_id = db.Column(db.Integer, db.ForeignKey('faculty.id'), nullable=False)
    year = db.Column(db.Integer, nullable=False)
    semester = db.Column(db.Integer, nullable=False)
    description = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationships
    enrollments = db.relationship('Enrollment', backref='course', lazy='dynamic')
    attendances = db.relationship('Attendance', backref='course', lazy='dynamic')
    class_schedules = db.relationship('ClassSchedule', backref='course', lazy='dynamic')
    
    def __repr__(self):
        return f'<Course {self.course_code}: {self.course_name}>'

class Enrollment(db.Model, UserMixin):
    __tablename__ = 'enrollments'
    
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('students.id'), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey('courses.id'), nullable=False)
    enrollment_date = db.Column(db.Date, default=db.func.current_date())
    status = db.Column(db.String(20), default='active')  # active, dropped, completed
    
    # Ensure unique enrollment per student per course
    __table_args__ = (db.UniqueConstraint('student_id', 'course_id', name='unique_student_course'),)
    
    def __repr__(self):
        return f'<Enrollment: Student {self.student_id} in Course {self.course_id}>'

class ClassSchedule(db.Model, UserMixin):
    __tablename__ = 'class_schedules'
    
    id = db.Column(db.Integer, primary_key=True)
    course_id = db.Column(db.Integer, db.ForeignKey('courses.id'), nullable=False)
    day_of_week = db.Column(db.Integer, nullable=False)  # 0=Monday, 6=Sunday
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    room = db.Column(db.String(50))
    is_active = db.Column(db.Boolean, default=True)
    
    def __repr__(self):
        return f'<ClassSchedule: {self.course.course_code} on day {self.day_of_week} at {self.start_time}>'

class Attendance(db.Model, UserMixin):
    __tablename__ = 'attendances'
    
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('students.id'), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey('courses.id'), nullable=False)
    class_date = db.Column(db.Date, nullable=False)
    class_time = db.Column(db.Time, nullable=False)
    marked_at = db.Column(db.DateTime, default=db.func.current_timestamp())
    status = db.Column(db.String(20), nullable=False)  # present, absent, late, excused
    method = db.Column(db.String(20), nullable=False)  # manual, face_recognition, rfid
    confidence_score = db.Column(db.Float)  # For face recognition confidence
    latitude = db.Column(db.Float)  # GPS coordinates for location verification
    longitude = db.Column(db.Float)
    ip_address = db.Column(db.String(45))
    device_info = db.Column(db.String(255))
    
    # Relationships
    student = db.relationship('Student', backref='attendance_records')
    course = db.relationship('Course', backref='attendance_records')
    
    # Ensure unique attendance per student per course per class
    __table_args__ = (db.UniqueConstraint('student_id', 'course_id', 'class_date', 'class_time', name='unique_attendance'),)
    
    def __repr__(self):
        return f'<Attendance: {self.student.student_id} in {self.course.course_code} on {self.class_date} - {self.status}>'

class AttendanceSession(db.Model, UserMixin):
    __tablename__ = 'attendance_sessions'
    
    id = db.Column(db.Integer, primary_key=True)
    course_id = db.Column(db.Integer, db.ForeignKey('courses.id'), nullable=False)
    session_date = db.Column(db.Date, nullable=False)
    start_time = db.Column(db.DateTime, nullable=False)
    end_time = db.Column(db.DateTime)
    room = db.Column(db.String(50))
    is_active = db.Column(db.Boolean, default=True)
    created_by = db.Column(db.Integer, db.ForeignKey('faculty.id'), nullable=False)
    
    # Relationships
    course = db.relationship('Course', backref='attendance_sessions')
    creator = db.relationship('Faculty', backref='created_sessions')
    
    def __repr__(self):
        return f'<AttendanceSession: {self.course.course_code} on {self.session_date}>'

class ProxyDetection(db.Model, UserMixin):
    __tablename__ = 'proxy_detections'
    
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('students.id'), nullable=False)
    suspected_proxy_id = db.Column(db.Integer, db.ForeignKey('students.id'), nullable=False)
    detection_method = db.Column(db.String(50), nullable=False)  # face_mismatch, location_mismatch, etc.
    confidence_score = db.Column(db.Float, nullable=False)
    evidence_data = db.Column(db.Text)  # JSON string with evidence
    is_verified = db.Column(db.Boolean, default=False)
    verified_by = db.Column(db.Integer, db.ForeignKey('faculty.id'))
    verified_at = db.Column(db.DateTime)
    
    # Relationships
    student = db.relationship('Student', foreign_keys=[student_id], backref='proxy_detections')
    suspected_proxy = db.relationship('Student', foreign_keys=[suspected_proxy_id])
    verifier = db.relationship('Faculty', backref='verified_detections')
    
    def __repr__(self):
        return f'<ProxyDetection: {self.student.student_id} suspected of proxy by {self.suspected_proxy.student_id}>'

# Analytics and Reporting Models
class AttendanceAnalytics(db.Model, UserMixin):
    __tablename__ = 'attendance_analytics'
    
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('students.id'))
    course_id = db.Column(db.Integer, db.ForeignKey('courses.id'))
    date = db.Column(db.Date, nullable=False)
    total_classes = db.Column(db.Integer, default=0)
    attended_classes = db.Column(db.Integer, default=0)
    late_classes = db.Column(db.Integer, default=0)
    absent_classes = db.Column(db.Integer, default=0)
    attendance_percentage = db.Column(db.Float, default=0.0)
    
    # Relationships
    student = db.relationship('Student', backref='analytics')
    course = db.relationship('Course', backref='analytics')
    
    def __repr__(self):
        return f'<AttendanceAnalytics: {self.student.student_id if self.student else "All"} - {self.attendance_percentage}%>'
