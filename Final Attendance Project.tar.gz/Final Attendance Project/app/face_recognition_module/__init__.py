"""
Facial Recognition Module for Student Attendance System
Provides face detection, recognition, and encoding functionality
"""

from .face_detector import FaceDetector
from .face_recognizer import FaceRecognizer
from .face_encoder import FaceEncoder

__all__ = ['FaceDetector', 'FaceRecognizer', 'FaceEncoder']
