"""
Simplified Face Encoding Module (without face_recognition library)
For demo purposes - uses OpenCV for basic face detection
"""

import cv2
import numpy as np
import json
import os
import logging
from typing import List, Optional, Tuple, Dict
import base64

logger = logging.getLogger(__name__)

class FaceEncoder:
    def __init__(self, model: str = 'haar'):
        """
        Initialize face encoder
        
        Args:
            model: Face encoding model ('haar' for OpenCV, 'cnn' for DNN)
        """
        self.model = model
        self.face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        self.encodings_cache = {}
    
    def encode_face(self, face_image: np.ndarray) -> Optional[np.ndarray]:
        """
        Generate face encoding from face image (simplified version)
        
        Args:
            face_image: Face image as numpy array
            
        Returns:
            Face encoding as numpy array or None if encoding failed
        """
        try:
            # Convert to grayscale if needed
            if len(face_image.shape) == 3:
                gray = cv2.cvtColor(face_image, cv2.COLOR_BGR2GRAY)
            else:
                gray = face_image
            
            # Resize to standard size
            face_resized = cv2.resize(gray, (128, 128))
            
            # Flatten and normalize
            face_encoding = face_resized.flatten().astype(np.float32)
            face_encoding = face_encoding / 255.0  # Normalize to 0-1
            
            return face_encoding
            
        except Exception as e:
            logger.error(f"Error encoding face: {str(e)}")
            return None
    
    def detect_faces(self, image: np.ndarray) -> List[Tuple[int, int, int, int]]:
        """
        Detect faces in image using OpenCV
        
        Args:
            image: Input image as numpy array
            
        Returns:
            List of face bounding boxes as (x, y, w, h) tuples
        """
        try:
            # Convert to grayscale
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            
            # Detect faces
            faces = self.face_cascade.detectMultiScale(
                gray,
                scaleFactor=1.1,
                minNeighbors=5,
                minSize=(30, 30)
            )
            
            return [(x, y, w, h) for x, y, w, h in faces]
            
        except Exception as e:
            logger.error(f"Error detecting faces: {str(e)}")
            return []
    
    def save_encoding(self, encoding: np.ndarray, student_id: str, encodings_dir: str) -> bool:
        """
        Save face encoding to file
        
        Args:
            encoding: Face encoding as numpy array
            student_id: Student ID for filename
            encodings_dir: Directory to save encodings
            
        Returns:
            True if saved successfully, False otherwise
        """
        try:
            os.makedirs(encodings_dir, exist_ok=True)
            
            # Convert numpy array to list for JSON serialization
            encoding_list = encoding.tolist()
            
            encoding_data = {
                'student_id': student_id,
                'encoding': encoding_list,
                'model': self.model
            }
            
            file_path = os.path.join(encodings_dir, f"{student_id}.json")
            
            with open(file_path, 'w') as f:
                json.dump(encoding_data, f)
            
            # Cache the encoding
            self.encodings_cache[student_id] = encoding
            
            logger.info(f"Face encoding saved for student {student_id}")
            return True
            
        except Exception as e:
            logger.error(f"Error saving encoding for student {student_id}: {str(e)}")
            return False
    
    def load_encoding(self, student_id: str, encodings_dir: str) -> Optional[np.ndarray]:
        """
        Load face encoding from file
        
        Args:
            student_id: Student ID
            encodings_dir: Directory containing encodings
            
        Returns:
            Face encoding as numpy array or None if not found
        """
        try:
            # Check cache first
            if student_id in self.encodings_cache:
                return self.encodings_cache[student_id]
            
            file_path = os.path.join(encodings_dir, f"{student_id}.json")
            
            if not os.path.exists(file_path):
                logger.warning(f"Encoding file not found for student {student_id}")
                return None
            
            with open(file_path, 'r') as f:
                encoding_data = json.load(f)
            
            # Convert list back to numpy array
            encoding = np.array(encoding_data['encoding'])
            
            # Cache the encoding
            self.encodings_cache[student_id] = encoding
            
            return encoding
            
        except Exception as e:
            logger.error(f"Error loading encoding for student {student_id}: {str(e)}")
            return None
    
    def encoding_to_json(self, encoding: np.ndarray) -> str:
        """
        Convert face encoding to JSON string
        
        Args:
            encoding: Face encoding as numpy array
            
        Returns:
            JSON string representation of encoding
        """
        try:
            encoding_data = {
                'encoding': encoding.tolist(),
                'model': self.model
            }
            return json.dumps(encoding_data)
        except Exception as e:
            logger.error(f"Error converting encoding to JSON: {str(e)}")
            return ""
    
    def json_to_encoding(self, json_string: str) -> Optional[np.ndarray]:
        """
        Convert JSON string to face encoding
        
        Args:
            json_string: JSON string representation of encoding
            
        Returns:
            Face encoding as numpy array or None if conversion failed
        """
        try:
            encoding_data = json.loads(json_string)
            return np.array(encoding_data['encoding'])
        except Exception as e:
            logger.error(f"Error converting JSON to encoding: {str(e)}")
            return None
