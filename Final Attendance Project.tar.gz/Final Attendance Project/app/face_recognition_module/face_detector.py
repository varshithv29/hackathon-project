"""
Face Detection Module
Handles face detection in images and video streams
"""

import cv2
import numpy as np
from typing import List, Tuple, Optional
import logging

logger = logging.getLogger(__name__)

class FaceDetector:
    def __init__(self, model_path: str = None):
        """
        Initialize face detector
        
        Args:
            model_path: Path to custom face detection model (optional)
        """
        self.face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        self.face_cascade_profile = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_profileface.xml')
        
        # Alternative: Use DNN-based face detection for better accuracy
        try:
            self.net = cv2.dnn.readNetFromTensorflow('models/opencv_face_detector_uint8.pb',
                                                   'models/opencv_face_detector.pbtxt')
            self.use_dnn = True
        except:
            self.use_dnn = False
            logger.warning("DNN face detection model not found, using Haar cascades")
    
    def detect_faces_haar(self, image: np.ndarray) -> List[Tuple[int, int, int, int]]:
        """
        Detect faces using Haar cascades
        
        Args:
            image: Input image as numpy array
            
        Returns:
            List of face bounding boxes as (x, y, w, h) tuples
        """
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # Detect frontal faces
        faces_frontal = self.face_cascade.detectMultiScale(
            gray,
            scaleFactor=1.1,
            minNeighbors=5,
            minSize=(30, 30),
            flags=cv2.CASCADE_SCALE_IMAGE
        )
        
        # Detect profile faces
        faces_profile = self.face_cascade_profile.detectMultiScale(
            gray,
            scaleFactor=1.1,
            minNeighbors=5,
            minSize=(30, 30),
            flags=cv2.CASCADE_SCALE_IMAGE
        )
        
        # Combine and remove duplicates
        all_faces = list(faces_frontal) + list(faces_profile)
        faces = self._remove_overlapping_faces(all_faces)
        
        return faces
    
    def detect_faces_dnn(self, image: np.ndarray, confidence_threshold: float = 0.7) -> List[Tuple[int, int, int, int]]:
        """
        Detect faces using DNN model
        
        Args:
            image: Input image as numpy array
            confidence_threshold: Minimum confidence for face detection
            
        Returns:
            List of face bounding boxes as (x, y, w, h) tuples
        """
        if not self.use_dnn:
            return self.detect_faces_haar(image)
        
        h, w = image.shape[:2]
        blob = cv2.dnn.blobFromImage(cv2.resize(image, (300, 300)), 1.0,
                                   (300, 300), (104.0, 177.0, 123.0))
        
        self.net.setInput(blob)
        detections = self.net.forward()
        
        faces = []
        for i in range(detections.shape[2]):
            confidence = detections[0, 0, i, 2]
            
            if confidence > confidence_threshold:
                box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
                x, y, x1, y1 = box.astype("int")
                faces.append((x, y, x1 - x, y1 - y))
        
        return faces
    
    def detect_faces(self, image: np.ndarray, method: str = 'auto') -> List[Tuple[int, int, int, int]]:
        """
        Detect faces in image using specified method
        
        Args:
            image: Input image as numpy array
            method: Detection method ('haar', 'dnn', 'auto')
            
        Returns:
            List of face bounding boxes as (x, y, w, h) tuples
        """
        if method == 'dnn' or (method == 'auto' and self.use_dnn):
            faces = self.detect_faces_dnn(image)
        else:
            faces = self.detect_faces_haar(image)
        
        # Filter out very small faces
        min_face_size = 50
        faces = [(x, y, w, h) for x, y, w, h in faces if w >= min_face_size and h >= min_face_size]
        
        return faces
    
    def _remove_overlapping_faces(self, faces: List[Tuple[int, int, int, int]], 
                                 overlap_threshold: float = 0.3) -> List[Tuple[int, int, int, int]]:
        """
        Remove overlapping face detections
        
        Args:
            faces: List of face bounding boxes
            overlap_threshold: Threshold for considering faces as overlapping
            
        Returns:
            List of non-overlapping face bounding boxes
        """
        if len(faces) <= 1:
            return faces
        
        # Convert to list of tuples for easier handling
        faces = [tuple(face) for face in faces]
        
        # Sort by area (largest first)
        faces.sort(key=lambda x: x[2] * x[3], reverse=True)
        
        filtered_faces = []
        for face in faces:
            is_overlapping = False
            for existing_face in filtered_faces:
                if self._calculate_overlap(face, existing_face) > overlap_threshold:
                    is_overlapping = True
                    break
            
            if not is_overlapping:
                filtered_faces.append(face)
        
        return filtered_faces
    
    def _calculate_overlap(self, face1: Tuple[int, int, int, int], 
                          face2: Tuple[int, int, int, int]) -> float:
        """
        Calculate overlap ratio between two face bounding boxes
        
        Args:
            face1: First face bounding box
            face2: Second face bounding box
            
        Returns:
            Overlap ratio (0.0 to 1.0)
        """
        x1, y1, w1, h1 = face1
        x2, y2, w2, h2 = face2
        
        # Calculate intersection
        x_left = max(x1, x2)
        y_top = max(y1, y2)
        x_right = min(x1 + w1, x2 + w2)
        y_bottom = min(y1 + h1, y2 + h2)
        
        if x_right < x_left or y_bottom < y_top:
            return 0.0
        
        intersection = (x_right - x_left) * (y_bottom - y_top)
        area1 = w1 * h1
        area2 = w2 * h2
        union = area1 + area2 - intersection
        
        return intersection / union if union > 0 else 0.0
    
    def extract_face_region(self, image: np.ndarray, face_box: Tuple[int, int, int, int]) -> np.ndarray:
        """
        Extract face region from image
        
        Args:
            image: Input image
            face_box: Face bounding box (x, y, w, h)
            
        Returns:
            Extracted face image
        """
        x, y, w, h = face_box
        return image[y:y+h, x:x+w]
    
    def preprocess_face(self, face_image: np.ndarray, target_size: Tuple[int, int] = (160, 160)) -> np.ndarray:
        """
        Preprocess face image for recognition
        
        Args:
            face_image: Face image
            target_size: Target size for resizing
            
        Returns:
            Preprocessed face image
        """
        # Resize to target size
        face_resized = cv2.resize(face_image, target_size)
        
        # Convert to RGB (OpenCV uses BGR)
        face_rgb = cv2.cvtColor(face_resized, cv2.COLOR_BGR2RGB)
        
        # Normalize pixel values
        face_normalized = face_rgb.astype(np.float32) / 255.0
        
        return face_normalized
