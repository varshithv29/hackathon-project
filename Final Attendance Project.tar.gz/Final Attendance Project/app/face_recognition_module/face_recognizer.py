"""
Simplified Face Recognition Module (without face_recognition library)
For demo purposes - uses OpenCV for basic face matching
"""

import cv2
import numpy as np
import logging
from typing import List, Tuple, Optional, Dict
from .face_encoder import FaceEncoder

logger = logging.getLogger(__name__)

class FaceRecognizer:
    def __init__(self, tolerance: float = 0.6, model: str = 'haar'):
        """
        Initialize face recognizer
        
        Args:
            tolerance: Face recognition tolerance (lower = more strict)
            model: Face encoding model
        """
        self.tolerance = tolerance
        self.face_encoder = FaceEncoder(model=model)
        self.known_encodings = {}
        self.known_student_ids = []
    
    def load_student_encodings(self, student_encodings: Dict[str, np.ndarray]) -> bool:
        """
        Load known student face encodings
        
        Args:
            student_encodings: Dictionary mapping student_id to face encoding
            
        Returns:
            True if loaded successfully, False otherwise
        """
        try:
            self.known_encodings = student_encodings.copy()
            self.known_student_ids = list(student_encodings.keys())
            
            logger.info(f"Loaded {len(self.known_student_ids)} student face encodings")
            return True
            
        except Exception as e:
            logger.error(f"Error loading student encodings: {str(e)}")
            return False
    
    def recognize_faces_in_image(self, image: np.ndarray) -> List[Tuple[str, float, Tuple[int, int, int, int]]]:
        """
        Recognize all faces in an image (simplified version)
        
        Args:
            image: Input image as numpy array
            
        Returns:
            List of tuples (student_id, confidence, face_location)
        """
        if not self.known_student_ids:
            logger.warning("No known faces loaded for recognition")
            return []
        
        try:
            # Detect faces in image
            face_locations = self.face_encoder.detect_faces(image)
            
            if not face_locations:
                logger.debug("No faces found in image")
                return []
            
            results = []
            
            for face_location in face_locations:
                x, y, w, h = face_location
                face_image = image[y:y+h, x:x+w]
                
                # Generate encoding for this face
                face_encoding = self.face_encoder.encode_face(face_image)
                
                if face_encoding is None:
                    continue
                
                # Find best match
                best_match = self._find_best_match(face_encoding)
                
                if best_match:
                    student_id, confidence = best_match
                    results.append((student_id, confidence, face_location))
                else:
                    results.append(("unknown", 0.0, face_location))
            
            return results
            
        except Exception as e:
            logger.error(f"Error recognizing faces in image: {str(e)}")
            return []
    
    def recognize_single_face(self, face_image: np.ndarray) -> Tuple[Optional[str], float]:
        """
        Recognize a single face from face image
        
        Args:
            face_image: Face image as numpy array
            
        Returns:
            Tuple of (student_id, confidence) or (None, 0.0) if not recognized
        """
        if not self.known_student_ids:
            return None, 0.0
        
        try:
            # Generate encoding for the face
            face_encoding = self.face_encoder.encode_face(face_image)
            
            if face_encoding is None:
                return None, 0.0
            
            # Find best match
            best_match = self._find_best_match(face_encoding)
            
            if best_match:
                return best_match
            
            return None, 0.0
            
        except Exception as e:
            logger.error(f"Error recognizing single face: {str(e)}")
            return None, 0.0
    
    def _find_best_match(self, face_encoding: np.ndarray) -> Optional[Tuple[str, float]]:
        """
        Find the best matching student for a face encoding
        
        Args:
            face_encoding: Face encoding to match
            
        Returns:
            Tuple of (student_id, confidence) or None if no good match
        """
        try:
            best_match = None
            best_distance = float('inf')
            
            for student_id, known_encoding in self.known_encodings.items():
                # Calculate Euclidean distance
                distance = np.linalg.norm(face_encoding - known_encoding)
                
                if distance < best_distance:
                    best_distance = distance
                    best_match = student_id
            
            # Convert distance to confidence (lower distance = higher confidence)
            # Normalize to 0-1 range
            max_distance = 50.0  # Approximate maximum distance for our encoding
            confidence = max(0.0, min(1.0, 1.0 - (best_distance / max_distance)))
            
            # Apply tolerance threshold
            if confidence >= self.tolerance:
                return best_match, confidence
            
            return None
            
        except Exception as e:
            logger.error(f"Error finding best match: {str(e)}")
            return None
    
    def add_student_encoding(self, student_id: str, face_encoding: np.ndarray) -> bool:
        """
        Add a new student face encoding
        
        Args:
            student_id: Student ID
            face_encoding: Face encoding as numpy array
            
        Returns:
            True if added successfully, False otherwise
        """
        try:
            self.known_encodings[student_id] = face_encoding
            self.known_student_ids.append(student_id)
            
            logger.info(f"Added face encoding for student {student_id}")
            return True
            
        except Exception as e:
            logger.error(f"Error adding student encoding for {student_id}: {str(e)}")
            return False
    
    def remove_student_encoding(self, student_id: str) -> bool:
        """
        Remove a student face encoding
        
        Args:
            student_id: Student ID
            
        Returns:
            True if removed successfully, False otherwise
        """
        try:
            if student_id in self.known_encodings:
                del self.known_encodings[student_id]
                self.known_student_ids.remove(student_id)
                
                logger.info(f"Removed face encoding for student {student_id}")
                return True
            else:
                logger.warning(f"Student {student_id} not found in known encodings")
                return False
                
        except Exception as e:
            logger.error(f"Error removing student encoding for {student_id}: {str(e)}")
            return False
    
    def get_known_students(self) -> List[str]:
        """
        Get list of known student IDs
        
        Returns:
            List of student IDs
        """
        return self.known_student_ids.copy()
    
    def get_encoding_count(self) -> int:
        """
        Get number of loaded face encodings
        
        Returns:
            Number of loaded encodings
        """
        return len(self.known_student_ids)
