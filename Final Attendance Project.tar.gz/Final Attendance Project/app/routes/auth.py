"""
Authentication Routes
Handles user login, logout, and registration
"""

from flask import Blueprint, request, jsonify, session
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import check_password_hash, generate_password_hash
from app.models import User, Student, Faculty
from app import db
import logging

logger = logging.getLogger(__name__)
bp = Blueprint('auth', __name__)

@bp.route('/login', methods=['POST'])
def login():
    """User login endpoint"""
    try:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
        
        if not username or not password:
            return jsonify({'error': 'Username and password required'}), 400
        
        # Find user by username or email
        user = User.query.filter(
            (User.username == username) | (User.email == username)
        ).first()
        
        if user and check_password_hash(user.password_hash, password):
            if user.is_active:
                login_user(user, remember=True)
                
                # Get user profile based on role
                profile_data = {}
                if user.role == 'student' and user.student_profile:
                    profile_data = {
                        'student_id': user.student_profile.student_id,
                        'first_name': user.student_profile.first_name,
                        'last_name': user.student_profile.last_name,
                        'department': user.student_profile.department,
                        'year': user.student_profile.year,
                        'semester': user.student_profile.semester
                    }
                elif user.role == 'faculty' and user.faculty_profile:
                    profile_data = {
                        'faculty_id': user.faculty_profile.faculty_id,
                        'first_name': user.faculty_profile.first_name,
                        'last_name': user.faculty_profile.last_name,
                        'department': user.faculty_profile.department,
                        'designation': user.faculty_profile.designation
                    }
                
                return jsonify({
                    'message': 'Login successful',
                    'user': {
                        'id': user.id,
                        'username': user.username,
                        'email': user.email,
                        'role': user.role,
                        'profile': profile_data
                    }
                }), 200
            else:
                return jsonify({'error': 'Account is deactivated'}), 403
        else:
            return jsonify({'error': 'Invalid credentials'}), 401
            
    except Exception as e:
        logger.error(f"Login error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@bp.route('/logout', methods=['POST'])
@login_required
def logout():
    """User logout endpoint"""
    try:
        logout_user()
        return jsonify({'message': 'Logout successful'}), 200
    except Exception as e:
        logger.error(f"Logout error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@bp.route('/register', methods=['POST'])
def register():
    """User registration endpoint (Admin only)"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['username', 'email', 'password', 'role']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Check if user already exists
        if User.query.filter_by(username=data['username']).first():
            return jsonify({'error': 'Username already exists'}), 400
        
        if User.query.filter_by(email=data['email']).first():
            return jsonify({'error': 'Email already exists'}), 400
        
        # Create user
        user = User(
            username=data['username'],
            email=data['email'],
            password_hash=generate_password_hash(data['password']),
            role=data['role']
        )
        
        db.session.add(user)
        db.session.commit()
        
        return jsonify({
            'message': 'User registered successfully',
            'user_id': user.id
        }), 201
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Registration error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@bp.route('/profile', methods=['GET'])
@login_required
def get_profile():
    """Get current user profile"""
    try:
        profile_data = {}
        
        if current_user.role == 'student' and current_user.student_profile:
            student = current_user.student_profile
            profile_data = {
                'student_id': student.student_id,
                'first_name': student.first_name,
                'last_name': student.last_name,
                'date_of_birth': student.date_of_birth.isoformat() if student.date_of_birth else None,
                'phone': student.phone,
                'address': student.address,
                'department': student.department,
                'year': student.year,
                'semester': student.semester,
                'emergency_contact': student.emergency_contact,
                'parent_phone': student.parent_phone
            }
        elif current_user.role == 'faculty' and current_user.faculty_profile:
            faculty = current_user.faculty_profile
            profile_data = {
                'faculty_id': faculty.faculty_id,
                'first_name': faculty.first_name,
                'last_name': faculty.last_name,
                'department': faculty.department,
                'designation': faculty.designation,
                'phone': faculty.phone,
                'email': faculty.email,
                'office_location': faculty.office_location
            }
        
        return jsonify({
            'user': {
                'id': current_user.id,
                'username': current_user.username,
                'email': current_user.email,
                'role': current_user.role,
                'profile': profile_data
            }
        }), 200
        
    except Exception as e:
        logger.error(f"Get profile error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@bp.route('/change-password', methods=['POST'])
@login_required
def change_password():
    """Change user password"""
    try:
        data = request.get_json()
        current_password = data.get('current_password')
        new_password = data.get('new_password')
        
        if not current_password or not new_password:
            return jsonify({'error': 'Current password and new password required'}), 400
        
        # Verify current password
        if not check_password_hash(current_user.password_hash, current_password):
            return jsonify({'error': 'Current password is incorrect'}), 400
        
        # Update password
        current_user.password_hash = generate_password_hash(new_password)
        db.session.commit()
        
        return jsonify({'message': 'Password changed successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Change password error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@bp.route('/check-auth', methods=['GET'])
def check_auth():
    """Check if user is authenticated"""
    if current_user.is_authenticated:
        profile_data = {}
        
        if current_user.role == 'student' and current_user.student_profile:
            profile_data = {
                'student_id': current_user.student_profile.student_id,
                'first_name': current_user.student_profile.first_name,
                'last_name': current_user.student_profile.last_name,
                'department': current_user.student_profile.department
            }
        elif current_user.role == 'faculty' and current_user.faculty_profile:
            profile_data = {
                'faculty_id': current_user.faculty_profile.faculty_id,
                'first_name': current_user.faculty_profile.first_name,
                'last_name': current_user.faculty_profile.last_name,
                'department': current_user.faculty_profile.department
            }
        
        return jsonify({
            'authenticated': True,
            'user': {
                'id': current_user.id,
                'username': current_user.username,
                'email': current_user.email,
                'role': current_user.role,
                'profile': profile_data
            }
        }), 200
    else:
        return jsonify({'authenticated': False}), 401
