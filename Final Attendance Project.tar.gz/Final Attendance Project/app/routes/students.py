"""
Student Routes
Handles student-related operations
"""

from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from app.models import Student, Course, Enrollment, Attendance
from app import db
from app.face_recognition_module import FaceEncoder
import logging
import base64
import cv2
import numpy as np
import os

logger = logging.getLogger(__name__)
bp = Blueprint('students', __name__)

@bp.route('/register-face', methods=['POST'])
@login_required
def register_face():
    """Register face encoding for a student"""
    try:
        if current_user.role != 'student':
            return jsonify({'error': 'Only students can register their faces'}), 403
        
        data = request.get_json()
        image_data = data.get('image_data')  # Base64 encoded image
        
        if not image_data:
            return jsonify({'error': 'Image data is required'}), 400
        
        # Decode base64 image
        try:
            # Remove data URL prefix if present
            if image_data.startswith('data:image'):
                image_data = image_data.split(',')[1]
            
            # Decode base64
            image_bytes = base64.b64decode(image_data)
            nparr = np.frombuffer(image_bytes, np.uint8)
            image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            if image is None:
                return jsonify({'error': 'Invalid image data'}), 400
                
        except Exception as e:
            return jsonify({'error': 'Failed to decode image'}), 400
        
        # Generate face encoding
        encoder = FaceEncoder()
        face_encoding = encoder.encode_face(image)
        
        if face_encoding is None:
            return jsonify({'error': 'No face detected in the image'}), 400
        
        # Save encoding to database
        student = current_user.student_profile
        encoding_json = encoder.encoding_to_json(face_encoding)
        student.face_encoding = encoding_json
        
        # Also save to file system
        encodings_dir = current_app.config.get('FACE_ENCODINGS_PATH', 'face_encodings')
        encoder.save_encoding(face_encoding, student.student_id, encodings_dir)
        
        db.session.commit()
        
        return jsonify({
            'message': 'Face registered successfully',
            'student_id': student.student_id
        }), 200
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Register face error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@bp.route('/courses', methods=['GET'])
@login_required
def get_student_courses():
    """Get courses for the current student"""
    try:
        if current_user.role != 'student':
            return jsonify({'error': 'Only students can access this endpoint'}), 403
        
        student = current_user.student_profile
        enrollments = Enrollment.query.filter_by(student_id=student.id, status='active').all()
        
        courses_data = []
        for enrollment in enrollments:
            course = enrollment.course
            courses_data.append({
                'course_id': course.id,
                'course_code': course.course_code,
                'course_name': course.course_name,
                'department': course.department,
                'credits': course.credits,
                'faculty_name': f"{course.faculty.first_name} {course.faculty.last_name}",
                'enrollment_date': enrollment.enrollment_date.isoformat()
            })
        
        return jsonify({
            'courses': courses_data,
            'total_count': len(courses_data)
        }), 200
        
    except Exception as e:
        logger.error(f"Get student courses error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@bp.route('/attendance/<int:course_id>', methods=['GET'])
@login_required
def get_student_attendance(course_id):
    """Get attendance records for a specific course"""
    try:
        if current_user.role != 'student':
            return jsonify({'error': 'Only students can access this endpoint'}), 403
        
        student = current_user.student_profile
        
        # Check if student is enrolled in the course
        enrollment = Enrollment.query.filter_by(
            student_id=student.id,
            course_id=course_id,
            status='active'
        ).first()
        
        if not enrollment:
            return jsonify({'error': 'Student not enrolled in this course'}), 403
        
        # Get attendance records
        attendances = Attendance.query.filter_by(
            student_id=student.id,
            course_id=course_id
        ).order_by(Attendance.class_date.desc(), Attendance.class_time.desc()).all()
        
        # Format response
        attendance_data = []
        for attendance in attendances:
            attendance_data.append({
                'id': attendance.id,
                'course_code': attendance.course.course_code,
                'course_name': attendance.course.course_name,
                'class_date': attendance.class_date.isoformat(),
                'class_time': attendance.class_time.isoformat(),
                'marked_at': attendance.marked_at.isoformat() if attendance.marked_at else None,
                'status': attendance.status,
                'method': attendance.method,
                'confidence_score': attendance.confidence_score
            })
        
        # Calculate summary
        total_classes = len(attendances)
        present_count = len([a for a in attendances if a.status == 'present'])
        absent_count = len([a for a in attendances if a.status == 'absent'])
        late_count = len([a for a in attendances if a.status == 'late'])
        excused_count = len([a for a in attendances if a.status == 'excused'])
        
        attendance_percentage = (present_count + late_count + excused_count) / total_classes * 100 if total_classes > 0 else 0
        
        return jsonify({
            'course_id': course_id,
            'course_code': enrollment.course.course_code,
            'course_name': enrollment.course.course_name,
            'attendance_records': attendance_data,
            'summary': {
                'total_classes': total_classes,
                'present': present_count,
                'absent': absent_count,
                'late': late_count,
                'excused': excused_count,
                'attendance_percentage': round(attendance_percentage, 2)
            }
        }), 200
        
    except Exception as e:
        logger.error(f"Get student attendance error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@bp.route('/attendance-summary', methods=['GET'])
@login_required
def get_student_attendance_summary():
    """Get overall attendance summary for the student"""
    try:
        if current_user.role != 'student':
            return jsonify({'error': 'Only students can access this endpoint'}), 403
        
        student = current_user.student_profile
        
        # Get all active enrollments
        enrollments = Enrollment.query.filter_by(student_id=student.id, status='active').all()
        
        summary_data = []
        overall_stats = {
            'total_courses': len(enrollments),
            'total_classes': 0,
            'total_present': 0,
            'total_absent': 0,
            'total_late': 0,
            'total_excused': 0,
            'overall_percentage': 0.0
        }
        
        for enrollment in enrollments:
            course = enrollment.course
            
            # Get attendance records for this course
            attendances = Attendance.query.filter_by(
                student_id=student.id,
                course_id=course.id
            ).all()
            
            total_classes = len(attendances)
            present_count = len([a for a in attendances if a.status == 'present'])
            absent_count = len([a for a in attendances if a.status == 'absent'])
            late_count = len([a for a in attendances if a.status == 'late'])
            excused_count = len([a for a in attendances if a.status == 'excused'])
            
            attendance_percentage = (present_count + late_count + excused_count) / total_classes * 100 if total_classes > 0 else 0
            
            course_summary = {
                'course_id': course.id,
                'course_code': course.course_code,
                'course_name': course.course_name,
                'total_classes': total_classes,
                'present': present_count,
                'absent': absent_count,
                'late': late_count,
                'excused': excused_count,
                'attendance_percentage': round(attendance_percentage, 2)
            }
            
            summary_data.append(course_summary)
            
            # Update overall stats
            overall_stats['total_classes'] += total_classes
            overall_stats['total_present'] += present_count
            overall_stats['total_absent'] += absent_count
            overall_stats['total_late'] += late_count
            overall_stats['total_excused'] += excused_count
        
        # Calculate overall percentage
        if overall_stats['total_classes'] > 0:
            overall_stats['overall_percentage'] = round(
                (overall_stats['total_present'] + overall_stats['total_late'] + overall_stats['total_excused']) / 
                overall_stats['total_classes'] * 100, 2
            )
        
        return jsonify({
            'student_id': student.student_id,
            'student_name': f"{student.first_name} {student.last_name}",
            'course_summaries': summary_data,
            'overall_stats': overall_stats
        }), 200
        
    except Exception as e:
        logger.error(f"Get student attendance summary error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@bp.route('/profile', methods=['GET'])
@login_required
def get_student_profile():
    """Get student profile information"""
    try:
        if current_user.role != 'student':
            return jsonify({'error': 'Only students can access this endpoint'}), 403
        
        student = current_user.student_profile
        
        profile_data = {
            'student_id': student.student_id,
            'first_name': student.first_name,
            'last_name': student.last_name,
            'date_of_birth': student.date_of_birth.isoformat() if student.date_of_birth else None,
            'phone': student.phone,
            'address': student.address,
            'department': student.department,
            'year': student.year,
            'semester': student.semester,
            'emergency_contact': student.emergency_contact,
            'parent_phone': student.parent_phone,
            'has_face_encoding': bool(student.face_encoding),
            'profile_image': student.profile_image
        }
        
        return jsonify(profile_data), 200
        
    except Exception as e:
        logger.error(f"Get student profile error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@bp.route('/profile', methods=['PUT'])
@login_required
def update_student_profile():
    """Update student profile information"""
    try:
        if current_user.role != 'student':
            return jsonify({'error': 'Only students can access this endpoint'}), 403
        
        data = request.get_json()
        student = current_user.student_profile
        
        # Update allowed fields
        allowed_fields = ['phone', 'address', 'emergency_contact', 'parent_phone']
        
        for field in allowed_fields:
            if field in data:
                setattr(student, field, data[field])
        
        db.session.commit()
        
        return jsonify({'message': 'Profile updated successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Update student profile error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500
