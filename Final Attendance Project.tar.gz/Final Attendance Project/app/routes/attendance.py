"""
Attendance Routes
Handles attendance marking, retrieval, and management
"""

from flask import Blueprint, request, jsonify, current_app
from flask_login import login_required, current_user
from datetime import datetime, date, time, timedelta
from app.models import Attendance, Student, Course, AttendanceSession, Enrollment
from app import db
from app.face_recognition_module import FaceRecognizer, FaceEncoder
import logging
import os
import json

logger = logging.getLogger(__name__)
bp = Blueprint('attendance', __name__)

def get_face_recognizer():
    """Get configured face recognizer instance"""
    recognizer = FaceRecognizer(tolerance=current_app.config.get('FACE_DETECTION_TOLERANCE', 0.6))
    
    # Load student encodings
    encodings_dir = current_app.config.get('FACE_ENCODINGS_PATH', 'face_encodings')
    encoder = FaceEncoder()
    student_encodings = encoder.load_all_encodings(encodings_dir)
    recognizer.load_student_encodings(student_encodings)
    
    return recognizer

@bp.route('/mark', methods=['POST'])
@login_required
def mark_attendance():
    """Mark attendance for students"""
    try:
        data = request.get_json()
        course_id = data.get('course_id')
        class_date = data.get('class_date')
        class_time = data.get('class_time')
        attendance_data = data.get('attendance_data', [])  # List of student attendance records
        
        if not all([course_id, class_date, class_time]):
            return jsonify({'error': 'Course ID, class date, and class time are required'}), 400
        
        # Verify faculty has access to this course
        if current_user.role == 'faculty':
            course = Course.query.filter_by(id=course_id, faculty_id=current_user.faculty_profile.id).first()
            if not course:
                return jsonify({'error': 'Course not found or access denied'}), 403
        
        # Parse date and time
        try:
            class_date = datetime.strptime(class_date, '%Y-%m-%d').date()
            class_time = datetime.strptime(class_time, '%H:%M').time()
        except ValueError:
            return jsonify({'error': 'Invalid date or time format'}), 400
        
        marked_attendances = []
        errors = []
        
        for record in attendance_data:
            student_id = record.get('student_id')
            status = record.get('status', 'present')  # present, absent, late, excused
            method = record.get('method', 'manual')  # manual, face_recognition, rfid
            confidence_score = record.get('confidence_score')
            
            if not student_id:
                errors.append('Student ID is required for each attendance record')
                continue
            
            # Check if student is enrolled in the course
            enrollment = Enrollment.query.filter_by(
                student_id=student_id, 
                course_id=course_id, 
                status='active'
            ).first()
            
            if not enrollment:
                errors.append(f'Student {student_id} is not enrolled in this course')
                continue
            
            # Check for existing attendance record
            existing_attendance = Attendance.query.filter_by(
                student_id=student_id,
                course_id=course_id,
                class_date=class_date,
                class_time=class_time
            ).first()
            
            if existing_attendance:
                # Update existing record
                existing_attendance.status = status
                existing_attendance.method = method
                existing_attendance.marked_at = datetime.utcnow()
                if confidence_score:
                    existing_attendance.confidence_score = confidence_score
                marked_attendances.append(existing_attendance)
            else:
                # Create new attendance record
                attendance = Attendance(
                    student_id=student_id,
                    course_id=course_id,
                    class_date=class_date,
                    class_time=class_time,
                    status=status,
                    method=method,
                    confidence_score=confidence_score,
                    ip_address=request.remote_addr,
                    device_info=request.headers.get('User-Agent', '')
                )
                db.session.add(attendance)
                marked_attendances.append(attendance)
        
        db.session.commit()
        
        return jsonify({
            'message': f'Attendance marked for {len(marked_attendances)} students',
            'marked_count': len(marked_attendances),
            'errors': errors
        }), 200
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Mark attendance error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@bp.route('/face-recognition', methods=['POST'])
@login_required
def mark_attendance_face_recognition():
    """Mark attendance using face recognition"""
    try:
        data = request.get_json()
        course_id = data.get('course_id')
        class_date = data.get('class_date')
        class_time = data.get('class_time')
        image_data = data.get('image_data')  # Base64 encoded image
        
        if not all([course_id, class_date, class_time, image_data]):
            return jsonify({'error': 'Course ID, class date, class time, and image data are required'}), 400
        
        # Parse date and time
        try:
            class_date = datetime.strptime(class_date, '%Y-%m-%d').date()
            class_time = datetime.strptime(class_time, '%H:%M').time()
        except ValueError:
            return jsonify({'error': 'Invalid date or time format'}), 400
        
        # Decode base64 image
        import base64
        import cv2
        import numpy as np
        
        try:
            # Remove data URL prefix if present
            if image_data.startswith('data:image'):
                image_data = image_data.split(',')[1]
            
            # Decode base64
            image_bytes = base64.b64decode(image_data)
            nparr = np.frombuffer(image_bytes, np.uint8)
            image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            if image is None:
                return jsonify({'error': 'Invalid image data'}), 400
                
        except Exception as e:
            return jsonify({'error': 'Failed to decode image'}), 400
        
        # Get face recognizer and recognize faces
        recognizer = get_face_recognizer()
        recognition_results = recognizer.recognize_faces_in_image(image)
        
        if not recognition_results:
            return jsonify({
                'message': 'No faces detected or recognized',
                'recognized_faces': []
            }), 200
        
        # Mark attendance for recognized students
        marked_attendances = []
        errors = []
        
        for student_id, confidence, face_location in recognition_results:
            if student_id == 'unknown':
                continue
            
            # Check if student is enrolled in the course
            enrollment = Enrollment.query.filter_by(
                student_id=student_id, 
                course_id=course_id, 
                status='active'
            ).first()
            
            if not enrollment:
                errors.append(f'Student {student_id} is not enrolled in this course')
                continue
            
            # Check for existing attendance record
            existing_attendance = Attendance.query.filter_by(
                student_id=student_id,
                course_id=course_id,
                class_date=class_date,
                class_time=class_time
            ).first()
            
            status = 'present'
            if existing_attendance:
                # Update existing record
                existing_attendance.status = status
                existing_attendance.method = 'face_recognition'
                existing_attendance.confidence_score = confidence
                existing_attendance.marked_at = datetime.utcnow()
                marked_attendances.append(existing_attendance)
            else:
                # Create new attendance record
                attendance = Attendance(
                    student_id=student_id,
                    course_id=course_id,
                    class_date=class_date,
                    class_time=class_time,
                    status=status,
                    method='face_recognition',
                    confidence_score=confidence,
                    ip_address=request.remote_addr,
                    device_info=request.headers.get('User-Agent', '')
                )
                db.session.add(attendance)
                marked_attendances.append(attendance)
        
        db.session.commit()
        
        return jsonify({
            'message': f'Attendance marked for {len(marked_attendances)} students via face recognition',
            'recognized_faces': [{'student_id': sid, 'confidence': conf, 'face_location': loc} 
                               for sid, conf, loc in recognition_results],
            'marked_count': len(marked_attendances),
            'errors': errors
        }), 200
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Face recognition attendance error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@bp.route('/get/<int:course_id>', methods=['GET'])
@login_required
def get_attendance(course_id):
    """Get attendance records for a course"""
    try:
        # Verify access to course
        if current_user.role == 'student':
            # Check if student is enrolled
            enrollment = Enrollment.query.filter_by(
                student_id=current_user.student_profile.id,
                course_id=course_id,
                status='active'
            ).first()
            if not enrollment:
                return jsonify({'error': 'Access denied'}), 403
        elif current_user.role == 'faculty':
            # Check if faculty teaches this course
            course = Course.query.filter_by(id=course_id, faculty_id=current_user.faculty_profile.id).first()
            if not course:
                return jsonify({'error': 'Access denied'}), 403
        
        # Get query parameters
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        student_id = request.args.get('student_id')
        
        # Build query
        query = Attendance.query.filter_by(course_id=course_id)
        
        if start_date:
            query = query.filter(Attendance.class_date >= datetime.strptime(start_date, '%Y-%m-%d').date())
        
        if end_date:
            query = query.filter(Attendance.class_date <= datetime.strptime(end_date, '%Y-%m-%d').date())
        
        if student_id:
            query = query.filter_by(student_id=student_id)
        elif current_user.role == 'student':
            query = query.filter_by(student_id=current_user.student_profile.id)
        
        # Execute query
        attendances = query.order_by(Attendance.class_date.desc(), Attendance.class_time.desc()).all()
        
        # Format response
        attendance_data = []
        for attendance in attendances:
            attendance_data.append({
                'id': attendance.id,
                'student_id': attendance.student.student_id,
                'student_name': f"{attendance.student.first_name} {attendance.student.last_name}",
                'course_code': attendance.course.course_code,
                'course_name': attendance.course.course_name,
                'class_date': attendance.class_date.isoformat(),
                'class_time': attendance.class_time.isoformat(),
                'marked_at': attendance.marked_at.isoformat() if attendance.marked_at else None,
                'status': attendance.status,
                'method': attendance.method,
                'confidence_score': attendance.confidence_score
            })
        
        return jsonify({
            'attendance_records': attendance_data,
            'total_count': len(attendance_data)
        }), 200
        
    except Exception as e:
        logger.error(f"Get attendance error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@bp.route('/summary/<int:course_id>', methods=['GET'])
@login_required
def get_attendance_summary(course_id):
    """Get attendance summary for a course"""
    try:
        # Verify access to course
        if current_user.role == 'student':
            enrollment = Enrollment.query.filter_by(
                student_id=current_user.student_profile.id,
                course_id=course_id,
                status='active'
            ).first()
            if not enrollment:
                return jsonify({'error': 'Access denied'}), 403
        elif current_user.role == 'faculty':
            course = Course.query.filter_by(id=course_id, faculty_id=current_user.faculty_profile.id).first()
            if not course:
                return jsonify({'error': 'Access denied'}), 403
        
        # Get all attendance records for the course
        attendances = Attendance.query.filter_by(course_id=course_id).all()
        
        # Calculate summary statistics
        total_classes = len(set((a.class_date, a.class_time) for a in attendances))
        
        # Group by student
        student_summary = {}
        for attendance in attendances:
            student_id = attendance.student_id
            if student_id not in student_summary:
                student_summary[student_id] = {
                    'student_id': attendance.student.student_id,
                    'student_name': f"{attendance.student.first_name} {attendance.student.last_name}",
                    'total_classes': 0,
                    'present': 0,
                    'absent': 0,
                    'late': 0,
                    'excused': 0,
                    'attendance_percentage': 0.0
                }
            
            student_summary[student_id]['total_classes'] = total_classes
            
            if attendance.status == 'present':
                student_summary[student_id]['present'] += 1
            elif attendance.status == 'absent':
                student_summary[student_id]['absent'] += 1
            elif attendance.status == 'late':
                student_summary[student_id]['late'] += 1
            elif attendance.status == 'excused':
                student_summary[student_id]['excused'] += 1
            
            # Calculate percentage
            total_attended = (student_summary[student_id]['present'] + 
                            student_summary[student_id]['late'] + 
                            student_summary[student_id]['excused'])
            if total_classes > 0:
                student_summary[student_id]['attendance_percentage'] = (total_attended / total_classes) * 100
        
        return jsonify({
            'course_id': course_id,
            'total_classes': total_classes,
            'student_summaries': list(student_summary.values())
        }), 200
        
    except Exception as e:
        logger.error(f"Get attendance summary error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@bp.route('/session/start', methods=['POST'])
@login_required
def start_attendance_session():
    """Start a new attendance session"""
    try:
        if current_user.role != 'faculty':
            return jsonify({'error': 'Only faculty can start attendance sessions'}), 403
        
        data = request.get_json()
        course_id = data.get('course_id')
        session_date = data.get('session_date')
        start_time = data.get('start_time')
        room = data.get('room')
        
        if not all([course_id, session_date, start_time]):
            return jsonify({'error': 'Course ID, session date, and start time are required'}), 400
        
        # Verify faculty teaches this course
        course = Course.query.filter_by(id=course_id, faculty_id=current_user.faculty_profile.id).first()
        if not course:
            return jsonify({'error': 'Course not found or access denied'}), 403
        
        # Parse date and time
        try:
            session_date = datetime.strptime(session_date, '%Y-%m-%d').date()
            start_time = datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S')
        except ValueError:
            return jsonify({'error': 'Invalid date or time format'}), 400
        
        # Create attendance session
        session = AttendanceSession(
            course_id=course_id,
            session_date=session_date,
            start_time=start_time,
            room=room,
            created_by=current_user.faculty_profile.id
        )
        
        db.session.add(session)
        db.session.commit()
        
        return jsonify({
            'message': 'Attendance session started successfully',
            'session_id': session.id
        }), 201
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Start attendance session error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@bp.route('/session/<int:session_id>/end', methods=['POST'])
@login_required
def end_attendance_session(session_id):
    """End an attendance session"""
    try:
        if current_user.role != 'faculty':
            return jsonify({'error': 'Only faculty can end attendance sessions'}), 403
        
        session = AttendanceSession.query.get_or_404(session_id)
        
        # Verify faculty created this session
        if session.created_by != current_user.faculty_profile.id:
            return jsonify({'error': 'Access denied'}), 403
        
        # End the session
        session.end_time = datetime.utcnow()
        session.is_active = False
        
        db.session.commit()
        
        return jsonify({'message': 'Attendance session ended successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"End attendance session error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500
