"""
Analytics Routes
Handles analytics and reporting functionality
"""

from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from app.models import Attendance, Student, Course, Enrollment, AttendanceAnalytics
from app import db
from datetime import datetime, date, timedelta
import pandas as pd
import logging

logger = logging.getLogger(__name__)
bp = Blueprint('analytics', __name__)

@bp.route('/dashboard', methods=['GET'])
@login_required
def get_dashboard_analytics():
    """Get dashboard analytics based on user role"""
    try:
        if current_user.role == 'student':
            return _get_student_dashboard_analytics()
        elif current_user.role == 'faculty':
            return _get_faculty_dashboard_analytics()
        elif current_user.role == 'admin':
            return _get_admin_dashboard_analytics()
        else:
            return jsonify({'error': 'Invalid user role'}), 403
            
    except Exception as e:
        logger.error(f"Get dashboard analytics error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

def _get_student_dashboard_analytics():
    """Get analytics for student dashboard"""
    student = current_user.student_profile
    
    # Get recent attendance (last 30 days)
    recent_date = date.today() - timedelta(days=30)
    recent_attendances = Attendance.query.filter(
        Attendance.student_id == student.id,
        Attendance.class_date >= recent_date
    ).all()
    
    # Calculate statistics
    total_recent_classes = len(recent_attendances)
    present_recent = len([a for a in recent_attendances if a.status == 'present'])
    absent_recent = len([a for a in recent_attendances if a.status == 'absent'])
    late_recent = len([a for a in recent_attendances if a.status == 'late'])
    
    recent_percentage = (present_recent + late_recent) / total_recent_classes * 100 if total_recent_classes > 0 else 0
    
    # Get overall statistics
    all_attendances = Attendance.query.filter_by(student_id=student.id).all()
    total_all_classes = len(all_attendances)
    present_all = len([a for a in all_attendances if a.status == 'present'])
    absent_all = len([a for a in all_attendances if a.status == 'absent'])
    late_all = len([a for a in all_attendances if a.status == 'late'])
    
    overall_percentage = (present_all + late_all) / total_all_classes * 100 if total_all_classes > 0 else 0
    
    # Get course-wise statistics
    enrollments = Enrollment.query.filter_by(student_id=student.id, status='active').all()
    course_stats = []
    
    for enrollment in enrollments:
        course = enrollment.course
        course_attendances = Attendance.query.filter_by(
            student_id=student.id,
            course_id=course.id
        ).all()
        
        course_total = len(course_attendances)
        course_present = len([a for a in course_attendances if a.status == 'present'])
        course_absent = len([a for a in course_attendances if a.status == 'absent'])
        course_late = len([a for a in course_attendances if a.status == 'late'])
        
        course_percentage = (course_present + course_late) / course_total * 100 if course_total > 0 else 0
        
        course_stats.append({
            'course_code': course.course_code,
            'course_name': course.course_name,
            'total_classes': course_total,
            'present': course_present,
            'absent': course_absent,
            'late': course_late,
            'percentage': round(course_percentage, 2)
        })
    
    return jsonify({
        'student_id': student.student_id,
        'student_name': f"{student.first_name} {student.last_name}",
        'recent_stats': {
            'period': 'Last 30 days',
            'total_classes': total_recent_classes,
            'present': present_recent,
            'absent': absent_recent,
            'late': late_recent,
            'percentage': round(recent_percentage, 2)
        },
        'overall_stats': {
            'total_classes': total_all_classes,
            'present': present_all,
            'absent': absent_all,
            'late': late_all,
            'percentage': round(overall_percentage, 2)
        },
        'course_stats': course_stats
    }), 200

def _get_faculty_dashboard_analytics():
    """Get analytics for faculty dashboard"""
    faculty = current_user.faculty_profile
    
    # Get courses taught by faculty
    courses = Course.query.filter_by(faculty_id=faculty.id, is_active=True).all()
    
    course_analytics = []
    total_students = 0
    total_classes = 0
    
    for course in courses:
        # Get enrolled students
        enrollments = Enrollment.query.filter_by(course_id=course.id, status='active').all()
        student_count = len(enrollments)
        total_students += student_count
        
        # Get attendance records
        attendances = Attendance.query.filter_by(course_id=course.id).all()
        unique_sessions = set((a.class_date, a.class_time) for a in attendances)
        class_count = len(unique_sessions)
        total_classes += class_count
        
        # Calculate average attendance
        total_attendance_records = len(attendances)
        present_count = len([a for a in attendances if a.status == 'present'])
        late_count = len([a for a in attendances if a.status == 'late'])
        
        avg_attendance = (present_count + late_count) / total_attendance_records * 100 if total_attendance_records > 0 else 0
        
        course_analytics.append({
            'course_id': course.id,
            'course_code': course.course_code,
            'course_name': course.course_name,
            'student_count': student_count,
            'total_classes': class_count,
            'avg_attendance': round(avg_attendance, 2)
        })
    
    # Get recent attendance trends (last 7 days)
    recent_date = date.today() - timedelta(days=7)
    recent_attendances = Attendance.query.join(Course).filter(
        Course.faculty_id == faculty.id,
        Attendance.class_date >= recent_date
    ).all()
    
    daily_stats = {}
    for attendance in recent_attendances:
        day = attendance.class_date.isoformat()
        if day not in daily_stats:
            daily_stats[day] = {'total': 0, 'present': 0, 'absent': 0}
        
        daily_stats[day]['total'] += 1
        if attendance.status == 'present':
            daily_stats[day]['present'] += 1
        elif attendance.status == 'absent':
            daily_stats[day]['absent'] += 1
    
    daily_trends = []
    for day, stats in daily_stats.items():
        percentage = stats['present'] / stats['total'] * 100 if stats['total'] > 0 else 0
        daily_trends.append({
            'date': day,
            'total_students': stats['total'],
            'present': stats['present'],
            'absent': stats['absent'],
            'percentage': round(percentage, 2)
        })
    
    return jsonify({
        'faculty_id': faculty.faculty_id,
        'faculty_name': f"{faculty.first_name} {faculty.last_name}",
        'department': faculty.department,
        'course_analytics': course_analytics,
        'summary': {
            'total_courses': len(courses),
            'total_students': total_students,
            'total_classes': total_classes
        },
        'daily_trends': daily_trends
    }), 200

def _get_admin_dashboard_analytics():
    """Get analytics for admin dashboard"""
    # Get overall statistics
    total_students = Student.query.count()
    total_faculty = Faculty.query.count()
    total_courses = Course.query.filter_by(is_active=True).count()
    
    # Get attendance statistics for the current semester
    current_date = date.today()
    semester_start = date(current_date.year, 1, 1)  # Assuming January start
    
    semester_attendances = Attendance.query.filter(
        Attendance.class_date >= semester_start
    ).all()
    
    total_attendance_records = len(semester_attendances)
    present_count = len([a for a in semester_attendances if a.status == 'present'])
    absent_count = len([a for a in semester_attendances if a.status == 'absent'])
    late_count = len([a for a in semester_attendances if a.status == 'late'])
    
    overall_attendance_percentage = (present_count + late_count) / total_attendance_records * 100 if total_attendance_records > 0 else 0
    
    # Get department-wise statistics
    departments = db.session.query(Student.department).distinct().all()
    dept_stats = []
    
    for (dept,) in departments:
        dept_students = Student.query.filter_by(department=dept).count()
        dept_attendances = Attendance.query.join(Student).filter(
            Student.department == dept,
            Attendance.class_date >= semester_start
        ).all()
        
        dept_total = len(dept_attendances)
        dept_present = len([a for a in dept_attendances if a.status == 'present'])
        dept_late = len([a for a in dept_attendances if a.status == 'late'])
        
        dept_percentage = (dept_present + dept_late) / dept_total * 100 if dept_total > 0 else 0
        
        dept_stats.append({
            'department': dept,
            'student_count': dept_students,
            'attendance_percentage': round(dept_percentage, 2)
        })
    
    # Get recent trends (last 30 days)
    recent_date = date.today() - timedelta(days=30)
    recent_attendances = Attendance.query.filter(
        Attendance.class_date >= recent_date
    ).all()
    
    # Group by date
    daily_attendance = {}
    for attendance in recent_attendances:
        day = attendance.class_date.isoformat()
        if day not in daily_attendance:
            daily_attendance[day] = {'total': 0, 'present': 0}
        
        daily_attendance[day]['total'] += 1
        if attendance.status in ['present', 'late']:
            daily_attendance[day]['present'] += 1
    
    daily_trends = []
    for day, stats in daily_attendance.items():
        percentage = stats['present'] / stats['total'] * 100 if stats['total'] > 0 else 0
        daily_trends.append({
            'date': day,
            'total_records': stats['total'],
            'present': stats['present'],
            'percentage': round(percentage, 2)
        })
    
    return jsonify({
        'overview': {
            'total_students': total_students,
            'total_faculty': total_faculty,
            'total_courses': total_courses,
            'overall_attendance_percentage': round(overall_attendance_percentage, 2)
        },
        'department_stats': dept_stats,
        'daily_trends': daily_trends,
        'semester_stats': {
            'total_attendance_records': total_attendance_records,
            'present': present_count,
            'absent': absent_count,
            'late': late_count
        }
    }), 200

@bp.route('/attendance-trends', methods=['GET'])
@login_required
def get_attendance_trends():
    """Get attendance trends over time"""
    try:
        # Get query parameters
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        course_id = request.args.get('course_id')
        department = request.args.get('department')
        
        # Build query
        query = Attendance.query
        
        if start_date:
            query = query.filter(Attendance.class_date >= datetime.strptime(start_date, '%Y-%m-%d').date())
        
        if end_date:
            query = query.filter(Attendance.class_date <= datetime.strptime(end_date, '%Y-%m-%d').date())
        
        if course_id:
            query = query.filter_by(course_id=course_id)
        
        if department:
            query = query.join(Student).filter(Student.department == department)
        
        # Execute query
        attendances = query.all()
        
        # Group by date
        daily_stats = {}
        for attendance in attendances:
            day = attendance.class_date.isoformat()
            if day not in daily_stats:
                daily_stats[day] = {'total': 0, 'present': 0, 'absent': 0, 'late': 0}
            
            daily_stats[day]['total'] += 1
            if attendance.status in daily_stats[day]:
                daily_stats[day][attendance.status] += 1
        
        # Format response
        trends = []
        for day, stats in sorted(daily_stats.items()):
            percentage = (stats['present'] + stats['late']) / stats['total'] * 100 if stats['total'] > 0 else 0
            trends.append({
                'date': day,
                'total_records': stats['total'],
                'present': stats['present'],
                'absent': stats['absent'],
                'late': stats['late'],
                'attendance_percentage': round(percentage, 2)
            })
        
        return jsonify({
            'trends': trends,
            'period': {
                'start_date': start_date,
                'end_date': end_date
            },
            'filters': {
                'course_id': course_id,
                'department': department
            }
        }), 200
        
    except Exception as e:
        logger.error(f"Get attendance trends error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@bp.route('/low-attendance-students', methods=['GET'])
@login_required
def get_low_attendance_students():
    """Get students with low attendance"""
    try:
        threshold = float(request.args.get('threshold', 75.0))  # Default 75%
        
        # Get all active students
        students = Student.query.all()
        
        low_attendance_students = []
        
        for student in students:
            # Get attendance records
            attendances = Attendance.query.filter_by(student_id=student.id).all()
            
            if not attendances:
                continue
            
            total_classes = len(attendances)
            present_count = len([a for a in attendances if a.status == 'present'])
            late_count = len([a for a in attendances if a.status == 'late'])
            
            attendance_percentage = (present_count + late_count) / total_classes * 100 if total_classes > 0 else 0
            
            if attendance_percentage < threshold:
                low_attendance_students.append({
                    'student_id': student.student_id,
                    'name': f"{student.first_name} {student.last_name}",
                    'department': student.department,
                    'year': student.year,
                    'total_classes': total_classes,
                    'present': present_count,
                    'late': late_count,
                    'attendance_percentage': round(attendance_percentage, 2)
                })
        
        # Sort by attendance percentage
        low_attendance_students.sort(key=lambda x: x['attendance_percentage'])
        
        return jsonify({
            'threshold': threshold,
            'low_attendance_students': low_attendance_students,
            'count': len(low_attendance_students)
        }), 200
        
    except Exception as e:
        logger.error(f"Get low attendance students error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500
