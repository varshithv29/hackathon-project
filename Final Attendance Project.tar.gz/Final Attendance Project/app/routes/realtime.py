"""
Real-time Attendance Tracking Routes
Handles WebSocket connections for live camera feeds and real-time attendance
"""

from flask import Blueprint, request, render_template
from flask_socketio import emit, join_room, leave_room
from flask_login import login_required, current_user
from app import socketio, db
from app.models import Attendance, Student, Course, Enrollment
from app.face_recognition_module import FaceRecognizer
from datetime import datetime, date, time
import base64
import cv2
import numpy as np
import logging

logger = logging.getLogger(__name__)
bp = Blueprint('realtime', __name__)

# Store active sessions
active_sessions = {}

@socketio.on('connect')
def handle_connect():
    """Handle client connection"""
    logger.info(f"Client connected: {request.sid}")
    emit('connected', {'message': 'Connected to attendance system'})

@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnection"""
    logger.info(f"Client disconnected: {request.sid}")
    # Clean up any active sessions
    for session_id, session_data in list(active_sessions.items()):
        if session_data.get('socket_id') == request.sid:
            del active_sessions[session_id]
            emit('session_ended', {'session_id': session_id}, room=session_id)

@socketio.on('join_session')
def handle_join_session(data):
    """Join an attendance session"""
    session_id = data.get('session_id')
    course_id = data.get('course_id')
    
    if not session_id or not course_id:
        emit('error', {'message': 'Session ID and Course ID are required'})
        return
    
    # Verify user has access to this course
    if current_user.role == 'faculty':
        from app.models import Course
        course = Course.query.filter_by(id=course_id, faculty_id=current_user.faculty_profile.id).first()
        if not course:
            emit('error', {'message': 'Access denied to this course'})
            return
    else:
        emit('error', {'message': 'Only faculty can manage attendance sessions'})
        return
    
    # Join the room
    join_room(session_id)
    
    # Initialize session if not exists
    if session_id not in active_sessions:
        active_sessions[session_id] = {
            'course_id': course_id,
            'faculty_id': current_user.faculty_profile.id,
            'socket_id': request.sid,
            'start_time': datetime.utcnow(),
            'recognized_faces': set(),
            'attendance_data': {}
        }
    
    emit('joined_session', {
        'session_id': session_id,
        'course_id': course_id,
        'message': 'Successfully joined attendance session'
    })

@socketio.on('leave_session')
def handle_leave_session(data):
    """Leave an attendance session"""
    session_id = data.get('session_id')
    
    if session_id:
        leave_room(session_id)
        emit('left_session', {'session_id': session_id})

@socketio.on('start_recognition')
def handle_start_recognition(data):
    """Start face recognition for attendance session"""
    session_id = data.get('session_id')
    
    if session_id not in active_sessions:
        emit('error', {'message': 'Session not found'})
        return
    
    session_data = active_sessions[session_id]
    course_id = session_data['course_id']
    
    # Initialize face recognizer for this session
    try:
        recognizer = FaceRecognizer(tolerance=0.6)
        # Load student encodings for this course
        enrollments = Enrollment.query.filter_by(course_id=course_id, status='active').all()
        student_encodings = {}
        
        for enrollment in enrollments:
            student = enrollment.student
            if student.face_encoding:
                from app.face_recognition_module import FaceEncoder
                encoder = FaceEncoder()
                encoding = encoder.json_to_encoding(student.face_encoding)
                if encoding is not None:
                    student_encodings[student.student_id] = encoding
        
        recognizer.load_student_encodings(student_encodings)
        session_data['recognizer'] = recognizer
        
        emit('recognition_started', {
            'session_id': session_id,
            'message': 'Face recognition started',
            'total_students': len(student_encodings)
        })
        
    except Exception as e:
        logger.error(f"Error starting recognition: {str(e)}")
        emit('error', {'message': 'Failed to start face recognition'})

@socketio.on('video_frame')
def handle_video_frame(data):
    """Process video frame for face recognition"""
    session_id = data.get('session_id')
    frame_data = data.get('frame_data')
    
    if session_id not in active_sessions:
        return
    
    session_data = active_sessions[session_id]
    
    if 'recognizer' not in session_data:
        return
    
    try:
        # Decode base64 image
        image_bytes = base64.b64decode(frame_data.split(',')[1])
        nparr = np.frombuffer(image_bytes, np.uint8)
        frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        if frame is None:
            return
        
        # Perform face recognition
        recognizer = session_data['recognizer']
        recognition_results = recognizer.recognize_faces_in_image(frame)
        
        # Process recognition results
        current_time = datetime.utcnow()
        recognized_students = []
        
        for student_id, confidence, face_location in recognition_results:
            if student_id == 'unknown' or confidence < 0.7:
                continue
            
            # Check if we've already recognized this student recently (within 5 seconds)
            last_recognition = session_data['attendance_data'].get(student_id, {}).get('last_seen')
            if last_recognition and (current_time - last_recognition).seconds < 5:
                continue
            
            # Update session data
            session_data['attendance_data'][student_id] = {
                'confidence': confidence,
                'face_location': face_location,
                'last_seen': current_time,
                'marked': False
            }
            
            session_data['recognized_faces'].add(student_id)
            
            recognized_students.append({
                'student_id': student_id,
                'confidence': round(confidence * 100, 1),
                'face_location': face_location
            })
        
        # Emit recognition results
        if recognized_students:
            emit('faces_recognized', {
                'session_id': session_id,
                'recognized_students': recognized_students,
                'total_recognized': len(session_data['recognized_faces'])
            }, room=session_id)
        
        # Auto-mark attendance for high confidence recognitions
        auto_mark_threshold = 0.8
        for student_data in recognized_students:
            if student_data['confidence'] / 100 >= auto_mark_threshold:
                student_id = student_data['student_id']
                if not session_data['attendance_data'][student_id]['marked']:
                    mark_attendance_auto(session_id, student_id, student_data['confidence'] / 100)
        
    except Exception as e:
        logger.error(f"Error processing video frame: {str(e)}")

@socketio.on('mark_attendance_manual')
def handle_mark_attendance_manual(data):
    """Manually mark attendance for a student"""
    session_id = data.get('session_id')
    student_id = data.get('student_id')
    status = data.get('status', 'present')
    
    if session_id not in active_sessions:
        emit('error', {'message': 'Session not found'})
        return
    
    session_data = active_sessions[session_id]
    course_id = session_data['course_id']
    
    try:
        # Mark attendance
        result = mark_attendance_auto(session_id, student_id, 1.0, status)
        
        if result:
            emit('attendance_marked', {
                'session_id': session_id,
                'student_id': student_id,
                'status': status,
                'message': f'Attendance marked for {student_id}'
            }, room=session_id)
        else:
            emit('error', {'message': 'Failed to mark attendance'})
            
    except Exception as e:
        logger.error(f"Error marking manual attendance: {str(e)}")
        emit('error', {'message': 'Failed to mark attendance'})

@socketio.on('get_session_status')
def handle_get_session_status(data):
    """Get current session status"""
    session_id = data.get('session_id')
    
    if session_id not in active_sessions:
        emit('error', {'message': 'Session not found'})
        return
    
    session_data = active_sessions[session_id]
    
    # Get enrolled students for this course
    enrollments = Enrollment.query.filter_by(course_id=session_data['course_id'], status='active').all()
    total_students = len(enrollments)
    
    # Count marked attendance
    marked_count = sum(1 for student_data in session_data['attendance_data'].values() 
                      if student_data['marked'])
    
    emit('session_status', {
        'session_id': session_id,
        'total_students': total_students,
        'recognized_faces': len(session_data['recognized_faces']),
        'marked_attendance': marked_count,
        'session_duration': (datetime.utcnow() - session_data['start_time']).seconds,
        'attendance_data': session_data['attendance_data']
    })

@socketio.on('end_session')
def handle_end_session(data):
    """End an attendance session"""
    session_id = data.get('session_id')
    
    if session_id not in active_sessions:
        emit('error', {'message': 'Session not found'})
        return
    
    session_data = active_sessions[session_id]
    
    # Finalize any remaining attendance records
    for student_id, student_data in session_data['attendance_data'].items():
        if not student_data['marked']:
            mark_attendance_auto(session_id, student_id, student_data['confidence'], 'absent')
    
    # Emit session summary
    enrollments = Enrollment.query.filter_by(course_id=session_data['course_id'], status='active').all()
    total_students = len(enrollments)
    marked_count = sum(1 for student_data in session_data['attendance_data'].values() 
                      if student_data['marked'])
    
    emit('session_ended', {
        'session_id': session_id,
        'summary': {
            'total_students': total_students,
            'marked_attendance': marked_count,
            'session_duration': (datetime.utcnow() - session_data['start_time']).seconds,
            'attendance_percentage': (marked_count / total_students * 100) if total_students > 0 else 0
        }
    }, room=session_id)
    
    # Clean up session
    del active_sessions[session_id]

def mark_attendance_auto(session_id, student_id, confidence, status='present'):
    """Automatically mark attendance for a student"""
    try:
        session_data = active_sessions[session_id]
        course_id = session_data['course_id']
        
        # Get student record
        student = Student.query.filter_by(student_id=student_id).first()
        if not student:
            return False
        
        # Check if attendance already exists for today
        today = date.today()
        existing_attendance = Attendance.query.filter_by(
            student_id=student.id,
            course_id=course_id,
            class_date=today
        ).first()
        
        if existing_attendance:
            # Update existing record
            existing_attendance.status = status
            existing_attendance.method = 'face_recognition'
            existing_attendance.confidence_score = confidence
            existing_attendance.marked_at = datetime.utcnow()
        else:
            # Create new attendance record
            attendance = Attendance(
                student_id=student.id,
                course_id=course_id,
                class_date=today,
                class_time=time(datetime.utcnow().hour, datetime.utcnow().minute),
                status=status,
                method='face_recognition',
                confidence_score=confidence,
                ip_address=request.remote_addr,
                device_info='Real-time face recognition'
            )
            db.session.add(attendance)
        
        db.session.commit()
        
        # Mark as processed in session data
        if student_id in session_data['attendance_data']:
            session_data['attendance_data'][student_id]['marked'] = True
        
        return True
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error marking automatic attendance: {str(e)}")
        return False

@bp.route('/live-attendance/<int:course_id>')
@login_required
def live_attendance_page(course_id):
    """Live attendance tracking page"""
    if current_user.role != 'faculty':
        return render_template('error.html', message='Access denied'), 403
    
    # Verify faculty teaches this course
    from app.models import Course
    course = Course.query.filter_by(id=course_id, faculty_id=current_user.faculty_profile.id).first()
    if not course:
        return render_template('error.html', message='Course not found'), 404
    
    return render_template('live_attendance.html', course=course)
