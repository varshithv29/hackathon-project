"""
Faculty Routes
Handles faculty-related operations
"""

from flask import Blueprint, request, jsonify, current_app
from flask_login import login_required, current_user
from app.models import Faculty, Course, Student, Enrollment, Attendance, ClassSchedule
from app import db
from datetime import datetime, date, time, timedelta
import logging

logger = logging.getLogger(__name__)
bp = Blueprint('faculty', __name__)

@bp.route('/courses', methods=['GET'])
@login_required
def get_faculty_courses():
    """Get courses taught by the current faculty"""
    try:
        if current_user.role != 'faculty':
            return jsonify({'error': 'Only faculty can access this endpoint'}), 403
        
        faculty = current_user.faculty_profile
        courses = Course.query.filter_by(faculty_id=faculty.id, is_active=True).all()
        
        courses_data = []
        for course in courses:
            # Get enrollment count
            enrollment_count = Enrollment.query.filter_by(course_id=course.id, status='active').count()
            
            # Get recent attendance count
            recent_date = date.today() - timedelta(days=30)
            recent_attendance = Attendance.query.filter(
                Attendance.course_id == course.id,
                Attendance.class_date >= recent_date
            ).count()
            
            courses_data.append({
                'course_id': course.id,
                'course_code': course.course_code,
                'course_name': course.course_name,
                'department': course.department,
                'credits': course.credits,
                'year': course.year,
                'semester': course.semester,
                'description': course.description,
                'enrollment_count': enrollment_count,
                'recent_attendance_count': recent_attendance
            })
        
        return jsonify({
            'courses': courses_data,
            'total_count': len(courses_data)
        }), 200
        
    except Exception as e:
        logger.error(f"Get faculty courses error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@bp.route('/course/<int:course_id>/students', methods=['GET'])
@login_required
def get_course_students(course_id):
    """Get students enrolled in a specific course"""
    try:
        if current_user.role != 'faculty':
            return jsonify({'error': 'Only faculty can access this endpoint'}), 403
        
        # Verify faculty teaches this course
        course = Course.query.filter_by(id=course_id, faculty_id=current_user.faculty_profile.id).first()
        if not course:
            return jsonify({'error': 'Course not found or access denied'}), 403
        
        # Get enrolled students
        enrollments = Enrollment.query.filter_by(course_id=course_id, status='active').all()
        
        students_data = []
        for enrollment in enrollments:
            student = enrollment.student
            students_data.append({
                'student_id': student.student_id,
                'first_name': student.first_name,
                'last_name': student.last_name,
                'department': student.department,
                'year': student.year,
                'semester': student.semester,
                'phone': student.phone,
                'has_face_encoding': bool(student.face_encoding),
                'enrollment_date': enrollment.enrollment_date.isoformat()
            })
        
        return jsonify({
            'course_id': course_id,
            'course_code': course.course_code,
            'course_name': course.course_name,
            'students': students_data,
            'total_count': len(students_data)
        }), 200
        
    except Exception as e:
        logger.error(f"Get course students error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@bp.route('/course/<int:course_id>/attendance-summary', methods=['GET'])
@login_required
def get_course_attendance_summary(course_id):
    """Get attendance summary for a course"""
    try:
        if current_user.role != 'faculty':
            return jsonify({'error': 'Only faculty can access this endpoint'}), 403
        
        # Verify faculty teaches this course
        course = Course.query.filter_by(id=course_id, faculty_id=current_user.faculty_profile.id).first()
        if not course:
            return jsonify({'error': 'Course not found or access denied'}), 403
        
        # Get all attendance records for the course
        attendances = Attendance.query.filter_by(course_id=course_id).all()
        
        # Calculate unique class sessions
        unique_sessions = set((a.class_date, a.class_time) for a in attendances)
        total_classes = len(unique_sessions)
        
        # Group by student
        student_summary = {}
        for attendance in attendances:
            student_id = attendance.student_id
            if student_id not in student_summary:
                student_summary[student_id] = {
                    'student_id': attendance.student.student_id,
                    'student_name': f"{attendance.student.first_name} {attendance.student.last_name}",
                    'department': attendance.student.department,
                    'year': attendance.student.year,
                    'total_classes': total_classes,
                    'present': 0,
                    'absent': 0,
                    'late': 0,
                    'excused': 0,
                    'attendance_percentage': 0.0
                }
            
            if attendance.status == 'present':
                student_summary[student_id]['present'] += 1
            elif attendance.status == 'absent':
                student_summary[student_id]['absent'] += 1
            elif attendance.status == 'late':
                student_summary[student_id]['late'] += 1
            elif attendance.status == 'excused':
                student_summary[student_id]['excused'] += 1
        
        # Calculate percentages
        for student_data in student_summary.values():
            total_attended = (student_data['present'] + student_data['late'] + student_data['excused'])
            if total_classes > 0:
                student_data['attendance_percentage'] = round((total_attended / total_classes) * 100, 2)
        
        # Sort by attendance percentage (descending)
        sorted_students = sorted(student_summary.values(), 
                               key=lambda x: x['attendance_percentage'], 
                               reverse=True)
        
        return jsonify({
            'course_id': course_id,
            'course_code': course.course_code,
            'course_name': course.course_name,
            'total_classes': total_classes,
            'student_summaries': sorted_students,
            'total_students': len(sorted_students)
        }), 200
        
    except Exception as e:
        logger.error(f"Get course attendance summary error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@bp.route('/course/<int:course_id>/schedule', methods=['GET'])
@login_required
def get_course_schedule(course_id):
    """Get class schedule for a course"""
    try:
        if current_user.role != 'faculty':
            return jsonify({'error': 'Only faculty can access this endpoint'}), 403
        
        # Verify faculty teaches this course
        course = Course.query.filter_by(id=course_id, faculty_id=current_user.faculty_profile.id).first()
        if not course:
            return jsonify({'error': 'Course not found or access denied'}), 403
        
        # Get class schedules
        schedules = ClassSchedule.query.filter_by(course_id=course_id, is_active=True).all()
        
        schedule_data = []
        for schedule in schedules:
            schedule_data.append({
                'id': schedule.id,
                'day_of_week': schedule.day_of_week,
                'day_name': ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'][schedule.day_of_week],
                'start_time': schedule.start_time.isoformat(),
                'end_time': schedule.end_time.isoformat(),
                'room': schedule.room
            })
        
        return jsonify({
            'course_id': course_id,
            'course_code': course.course_code,
            'schedules': schedule_data
        }), 200
        
    except Exception as e:
        logger.error(f"Get course schedule error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@bp.route('/course/<int:course_id>/schedule', methods=['POST'])
@login_required
def create_course_schedule(course_id):
    """Create a new class schedule for a course"""
    try:
        if current_user.role != 'faculty':
            return jsonify({'error': 'Only faculty can access this endpoint'}), 403
        
        # Verify faculty teaches this course
        course = Course.query.filter_by(id=course_id, faculty_id=current_user.faculty_profile.id).first()
        if not course:
            return jsonify({'error': 'Course not found or access denied'}), 403
        
        data = request.get_json()
        day_of_week = data.get('day_of_week')
        start_time = data.get('start_time')
        end_time = data.get('end_time')
        room = data.get('room')
        
        if not all([day_of_week is not None, start_time, end_time]):
            return jsonify({'error': 'Day of week, start time, and end time are required'}), 400
        
        try:
            start_time = datetime.strptime(start_time, '%H:%M').time()
            end_time = datetime.strptime(end_time, '%H:%M').time()
        except ValueError:
            return jsonify({'error': 'Invalid time format. Use HH:MM'}), 400
        
        # Create schedule
        schedule = ClassSchedule(
            course_id=course_id,
            day_of_week=day_of_week,
            start_time=start_time,
            end_time=end_time,
            room=room
        )
        
        db.session.add(schedule)
        db.session.commit()
        
        return jsonify({
            'message': 'Class schedule created successfully',
            'schedule_id': schedule.id
        }), 201
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Create course schedule error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@bp.route('/schedule/<int:schedule_id>', methods=['DELETE'])
@login_required
def delete_course_schedule(schedule_id):
    """Delete a class schedule"""
    try:
        if current_user.role != 'faculty':
            return jsonify({'error': 'Only faculty can access this endpoint'}), 403
        
        schedule = ClassSchedule.query.get_or_404(schedule_id)
        
        # Verify faculty teaches this course
        if schedule.course.faculty_id != current_user.faculty_profile.id:
            return jsonify({'error': 'Access denied'}), 403
        
        # Deactivate instead of delete
        schedule.is_active = False
        db.session.commit()
        
        return jsonify({'message': 'Class schedule deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Delete course schedule error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@bp.route('/profile', methods=['GET'])
@login_required
def get_faculty_profile():
    """Get faculty profile information"""
    try:
        if current_user.role != 'faculty':
            return jsonify({'error': 'Only faculty can access this endpoint'}), 403
        
        faculty = current_user.faculty_profile
        
        profile_data = {
            'faculty_id': faculty.faculty_id,
            'first_name': faculty.first_name,
            'last_name': faculty.last_name,
            'department': faculty.department,
            'designation': faculty.designation,
            'phone': faculty.phone,
            'email': faculty.email,
            'office_location': faculty.office_location
        }
        
        return jsonify(profile_data), 200
        
    except Exception as e:
        logger.error(f"Get faculty profile error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@bp.route('/profile', methods=['PUT'])
@login_required
def update_faculty_profile():
    """Update faculty profile information"""
    try:
        if current_user.role != 'faculty':
            return jsonify({'error': 'Only faculty can access this endpoint'}), 403
        
        data = request.get_json()
        faculty = current_user.faculty_profile
        
        # Update allowed fields
        allowed_fields = ['phone', 'email', 'office_location']
        
        for field in allowed_fields:
            if field in data:
                setattr(faculty, field, data[field])
        
        db.session.commit()
        
        return jsonify({'message': 'Profile updated successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Update faculty profile error: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500
