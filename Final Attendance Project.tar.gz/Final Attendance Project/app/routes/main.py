"""
Main Routes
Handles main application routes and dashboard
"""

from flask import Blueprint, render_template, jsonify
from flask_login import login_required, current_user

bp = Blueprint('main', __name__)

@bp.route('/')
def index():
    """Home page"""
    return render_template('index.html')

@bp.route('/dashboard')
@login_required
def dashboard():
    """User dashboard based on role"""
    if current_user.role == 'student':
        return render_template('student_dashboard.html')
    elif current_user.role == 'faculty':
        return render_template('faculty_dashboard.html')
    elif current_user.role == 'admin':
        return render_template('admin_dashboard.html')
    else:
        return render_template('index.html')

@bp.route('/attendance')
@login_required
def attendance_page():
    """Attendance management page"""
    if current_user.role == 'student':
        return render_template('student_attendance.html')
    elif current_user.role == 'faculty':
        return render_template('faculty_attendance.html')
    else:
        return render_template('index.html')

@bp.route('/analytics')
@login_required
def analytics_page():
    """Analytics page"""
    if current_user.role == 'admin':
        return render_template('admin_analytics.html')
    else:
        return render_template('index.html')

@bp.route('/profile')
@login_required
def profile_page():
    """User profile page"""
    return render_template('profile.html')

@bp.route('/help')
def help_page():
    """Help and documentation page"""
    return render_template('help.html')
