"""
Proxy Detection Module
Implements anti-fraud mechanisms to detect proxy attendance
"""

import numpy as np
import cv2
from datetime import datetime, timedelta
from typing import List, Dict, Tuple, Optional
import logging
from app.models import Attendance, Student, ProxyDetection
from app.face_recognition_module import FaceRecognizer
import json

logger = logging.getLogger(__name__)

class ProxyDetector:
    def __init__(self):
        """Initialize proxy detection system"""
        self.face_recognizer = FaceRecognizer(tolerance=0.5)  # More strict for proxy detection
        self.detection_methods = {
            'face_mismatch': self.detect_face_mismatch,
            'location_mismatch': self.detect_location_mismatch,
            'time_anomaly': self.detect_time_anomaly,
            'device_fingerprint': self.detect_device_fingerprint,
            'behavioral_analysis': self.detect_behavioral_anomaly
        }
    
    def detect_face_mismatch(self, student_id: str, face_image: np.ndarray, 
                           confidence_threshold: float = 0.7) -> Dict:
        """
        Detect if the face in the image matches the registered student's face
        
        Args:
            student_id: Student ID to verify
            face_image: Face image to verify
            confidence_threshold: Minimum confidence threshold
            
        Returns:
            Detection result dictionary
        """
        try:
            # Get student's registered face encoding
            student = Student.query.filter_by(student_id=student_id).first()
            if not student or not student.face_encoding:
                return {
                    'method': 'face_mismatch',
                    'is_proxy': True,
                    'confidence': 1.0,
                    'reason': 'No face encoding found for student',
                    'evidence': 'Student has no registered face encoding'
                }
            
            # Load student's face encoding
            from app.face_recognition_module import FaceEncoder
            encoder = FaceEncoder()
            student_encoding = encoder.json_to_encoding(student.face_encoding)
            
            if student_encoding is None:
                return {
                    'method': 'face_mismatch',
                    'is_proxy': True,
                    'confidence': 1.0,
                    'reason': 'Invalid face encoding for student',
                    'evidence': 'Student face encoding is corrupted'
                }
            
            # Generate encoding for the provided image
            provided_encoding = encoder.encode_face(face_image)
            
            if provided_encoding is None:
                return {
                    'method': 'face_mismatch',
                    'is_proxy': True,
                    'confidence': 0.9,
                    'reason': 'No face detected in provided image',
                    'evidence': 'Face detection failed on provided image'
                }
            
            # Compare face encodings
            import face_recognition
            face_distance = face_recognition.face_distance([student_encoding], provided_encoding)[0]
            similarity = 1 - face_distance
            
            is_proxy = similarity < confidence_threshold
            
            return {
                'method': 'face_mismatch',
                'is_proxy': is_proxy,
                'confidence': 1 - similarity,
                'reason': f'Face similarity: {similarity:.2f}, threshold: {confidence_threshold}',
                'evidence': {
                    'similarity_score': similarity,
                    'face_distance': face_distance,
                    'threshold': confidence_threshold
                }
            }
            
        except Exception as e:
            logger.error(f"Error in face mismatch detection: {str(e)}")
            return {
                'method': 'face_mismatch',
                'is_proxy': False,
                'confidence': 0.0,
                'reason': f'Detection error: {str(e)}',
                'evidence': 'Error during face comparison'
            }
    
    def detect_location_mismatch(self, student_id: str, attendance_record: Attendance) -> Dict:
        """
        Detect if attendance location is suspicious based on historical patterns
        
        Args:
            student_id: Student ID
            attendance_record: Current attendance record
            
        Returns:
            Detection result dictionary
        """
        try:
            student = Student.query.filter_by(student_id=student_id).first()
            if not student:
                return {
                    'method': 'location_mismatch',
                    'is_proxy': False,
                    'confidence': 0.0,
                    'reason': 'Student not found',
                    'evidence': 'Invalid student ID'
                }
            
            # Get historical attendance locations
            historical_attendances = Attendance.query.filter(
                Attendance.student_id == student.id,
                Attendance.latitude.isnot(None),
                Attendance.longitude.isnot(None),
                Attendance.marked_at >= datetime.utcnow() - timedelta(days=30)
            ).all()
            
            if len(historical_attendances) < 5:
                return {
                    'method': 'location_mismatch',
                    'is_proxy': False,
                    'confidence': 0.0,
                    'reason': 'Insufficient location history',
                    'evidence': f'Only {len(historical_attendances)} historical records'
                }
            
            # Calculate average location
            avg_lat = np.mean([a.latitude for a in historical_attendances])
            avg_lng = np.mean([a.longitude for a in historical_attendances])
            
            # Calculate distance from average location
            if attendance_record.latitude and attendance_record.longitude:
                distance = self._calculate_distance(
                    avg_lat, avg_lng,
                    attendance_record.latitude, attendance_record.longitude
                )
                
                # If distance is more than 1km, it's suspicious
                is_proxy = distance > 1.0  # 1 kilometer
                confidence = min(distance / 5.0, 1.0)  # Max confidence at 5km
                
                return {
                    'method': 'location_mismatch',
                    'is_proxy': is_proxy,
                    'confidence': confidence,
                    'reason': f'Distance from usual location: {distance:.2f} km',
                    'evidence': {
                        'distance_km': distance,
                        'avg_location': [avg_lat, avg_lng],
                        'current_location': [attendance_record.latitude, attendance_record.longitude],
                        'threshold_km': 1.0
                    }
                }
            else:
                return {
                    'method': 'location_mismatch',
                    'is_proxy': False,
                    'confidence': 0.0,
                    'reason': 'No location data in attendance record',
                    'evidence': 'GPS coordinates not available'
                }
                
        except Exception as e:
            logger.error(f"Error in location mismatch detection: {str(e)}")
            return {
                'method': 'location_mismatch',
                'is_proxy': False,
                'confidence': 0.0,
                'reason': f'Detection error: {str(e)}',
                'evidence': 'Error during location analysis'
            }
    
    def detect_time_anomaly(self, student_id: str, attendance_record: Attendance) -> Dict:
        """
        Detect if attendance time is anomalous based on historical patterns
        
        Args:
            student_id: Student ID
            attendance_record: Current attendance record
            
        Returns:
            Detection result dictionary
        """
        try:
            student = Student.query.filter_by(student_id=student_id).first()
            if not student:
                return {
                    'method': 'time_anomaly',
                    'is_proxy': False,
                    'confidence': 0.0,
                    'reason': 'Student not found',
                    'evidence': 'Invalid student ID'
                }
            
            # Get historical attendance times for the same course and day of week
            historical_attendances = Attendance.query.filter(
                Attendance.student_id == student.id,
                Attendance.course_id == attendance_record.course_id,
                Attendance.marked_at >= datetime.utcnow() - timedelta(days=60)
            ).all()
            
            if len(historical_attendances) < 3:
                return {
                    'method': 'time_anomaly',
                    'is_proxy': False,
                    'confidence': 0.0,
                    'reason': 'Insufficient attendance history',
                    'evidence': f'Only {len(historical_attendances)} historical records'
                }
            
            # Calculate average attendance time
            attendance_times = []
            for record in historical_attendances:
                if record.marked_at:
                    attendance_times.append(record.marked_at.time())
            
            if not attendance_times:
                return {
                    'method': 'time_anomaly',
                    'is_proxy': False,
                    'confidence': 0.0,
                    'reason': 'No valid time data in history',
                    'evidence': 'Historical records missing time information'
                }
            
            # Calculate average time
            avg_time = self._calculate_average_time(attendance_times)
            current_time = attendance_record.marked_at.time() if attendance_record.marked_at else None
            
            if not current_time:
                return {
                    'method': 'time_anomaly',
                    'is_proxy': False,
                    'confidence': 0.0,
                    'reason': 'No time data in current record',
                    'evidence': 'Current attendance record missing time'
                }
            
            # Calculate time difference
            time_diff_minutes = self._time_difference_minutes(avg_time, current_time)
            
            # If difference is more than 30 minutes, it's suspicious
            is_proxy = abs(time_diff_minutes) > 30
            confidence = min(abs(time_diff_minutes) / 60, 1.0)  # Max confidence at 1 hour
            
            return {
                'method': 'time_anomaly',
                'is_proxy': is_proxy,
                'confidence': confidence,
                'reason': f'Time difference from average: {time_diff_minutes:.1f} minutes',
                'evidence': {
                    'time_difference_minutes': time_diff_minutes,
                    'average_time': avg_time.isoformat(),
                    'current_time': current_time.isoformat(),
                    'threshold_minutes': 30
                }
            }
            
        except Exception as e:
            logger.error(f"Error in time anomaly detection: {str(e)}")
            return {
                'method': 'time_anomaly',
                'is_proxy': False,
                'confidence': 0.0,
                'reason': f'Detection error: {str(e)}',
                'evidence': 'Error during time analysis'
            }
    
    def detect_device_fingerprint(self, student_id: str, attendance_record: Attendance) -> Dict:
        """
        Detect if device fingerprint is consistent with historical data
        
        Args:
            student_id: Student ID
            attendance_record: Current attendance record
            
        Returns:
            Detection result dictionary
        """
        try:
            student = Student.query.filter_by(student_id=student_id).first()
            if not student:
                return {
                    'method': 'device_fingerprint',
                    'is_proxy': False,
                    'confidence': 0.0,
                    'reason': 'Student not found',
                    'evidence': 'Invalid student ID'
                }
            
            # Get historical device information
            historical_attendances = Attendance.query.filter(
                Attendance.student_id == student.id,
                Attendance.device_info.isnot(None),
                Attendance.marked_at >= datetime.utcnow() - timedelta(days=30)
            ).all()
            
            if len(historical_attendances) < 3:
                return {
                    'method': 'device_fingerprint',
                    'is_proxy': False,
                    'confidence': 0.0,
                    'reason': 'Insufficient device history',
                    'evidence': f'Only {len(historical_attendances)} historical records'
                }
            
            # Get most common device info
            device_counts = {}
            for record in historical_attendances:
                device_info = record.device_info
                device_counts[device_info] = device_counts.get(device_info, 0) + 1
            
            most_common_device = max(device_counts, key=device_counts.get)
            current_device = attendance_record.device_info or ''
            
            # Check if current device matches most common device
            device_match = most_common_device == current_device
            confidence = device_counts.get(current_device, 0) / len(historical_attendances)
            
            is_proxy = not device_match and confidence < 0.3
            
            return {
                'method': 'device_fingerprint',
                'is_proxy': is_proxy,
                'confidence': 1 - confidence,
                'reason': f'Device consistency: {confidence:.2f}',
                'evidence': {
                    'most_common_device': most_common_device,
                    'current_device': current_device,
                    'device_match': device_match,
                    'consistency_score': confidence
                }
            }
            
        except Exception as e:
            logger.error(f"Error in device fingerprint detection: {str(e)}")
            return {
                'method': 'device_fingerprint',
                'is_proxy': False,
                'confidence': 0.0,
                'reason': f'Detection error: {str(e)}',
                'evidence': 'Error during device analysis'
            }
    
    def detect_behavioral_anomaly(self, student_id: str, attendance_record: Attendance) -> Dict:
        """
        Detect behavioral anomalies in attendance patterns
        
        Args:
            student_id: Student ID
            attendance_record: Current attendance record
            
        Returns:
            Detection result dictionary
        """
        try:
            student = Student.query.filter_by(student_id=student_id).first()
            if not student:
                return {
                    'method': 'behavioral_analysis',
                    'is_proxy': False,
                    'confidence': 0.0,
                    'reason': 'Student not found',
                    'evidence': 'Invalid student ID'
                }
            
            # Get recent attendance history
            recent_attendances = Attendance.query.filter(
                Attendance.student_id == student.id,
                Attendance.marked_at >= datetime.utcnow() - timedelta(days=14)
            ).order_by(Attendance.marked_at.desc()).all()
            
            if len(recent_attendances) < 5:
                return {
                    'method': 'behavioral_analysis',
                    'is_proxy': False,
                    'confidence': 0.0,
                    'reason': 'Insufficient attendance history',
                    'evidence': f'Only {len(recent_attendances)} recent records'
                }
            
            # Analyze attendance patterns
            anomalies = []
            
            # Check for sudden change in attendance method
            methods = [record.method for record in recent_attendances if record.method]
            if methods:
                most_common_method = max(set(methods), key=methods.count)
                current_method = attendance_record.method
                if current_method != most_common_method:
                    anomalies.append(f'Method changed from {most_common_method} to {current_method}')
            
            # Check for rapid successive attendances (potential system abuse)
            if len(recent_attendances) > 0:
                last_attendance = recent_attendances[0]
                if attendance_record.marked_at and last_attendance.marked_at:
                    time_diff = (attendance_record.marked_at - last_attendance.marked_at).total_seconds()
                    if time_diff < 60:  # Less than 1 minute
                        anomalies.append(f'Rapid successive attendance: {time_diff}s apart')
            
            # Check for attendance outside normal hours (8 AM to 6 PM)
            if attendance_record.marked_at:
                hour = attendance_record.marked_at.hour
                if hour < 8 or hour > 18:
                    anomalies.append(f'Attendance outside normal hours: {hour}:00')
            
            is_proxy = len(anomalies) > 0
            confidence = min(len(anomalies) / 3.0, 1.0)  # Max confidence with 3+ anomalies
            
            return {
                'method': 'behavioral_analysis',
                'is_proxy': is_proxy,
                'confidence': confidence,
                'reason': f'Found {len(anomalies)} behavioral anomalies',
                'evidence': {
                    'anomalies': anomalies,
                    'anomaly_count': len(anomalies),
                    'recent_records_analyzed': len(recent_attendances)
                }
            }
            
        except Exception as e:
            logger.error(f"Error in behavioral analysis: {str(e)}")
            return {
                'method': 'behavioral_analysis',
                'is_proxy': False,
                'confidence': 0.0,
                'reason': f'Detection error: {str(e)}',
                'evidence': 'Error during behavioral analysis'
            }
    
    def detect_proxy_attendance(self, student_id: str, face_image: np.ndarray = None, 
                               attendance_record: Attendance = None) -> Dict:
        """
        Comprehensive proxy detection using multiple methods
        
        Args:
            student_id: Student ID
            face_image: Optional face image for verification
            attendance_record: Optional attendance record for analysis
            
        Returns:
            Comprehensive detection result
        """
        detection_results = []
        
        # Face mismatch detection (if face image provided)
        if face_image is not None:
            face_result = self.detect_face_mismatch(student_id, face_image)
            detection_results.append(face_result)
        
        # Other detection methods (if attendance record provided)
        if attendance_record is not None:
            location_result = self.detect_location_mismatch(student_id, attendance_record)
            detection_results.append(location_result)
            
            time_result = self.detect_time_anomaly(student_id, attendance_record)
            detection_results.append(time_result)
            
            device_result = self.detect_device_fingerprint(student_id, attendance_record)
            detection_results.append(device_result)
            
            behavioral_result = self.detect_behavioral_anomaly(student_id, attendance_record)
            detection_results.append(behavioral_result)
        
        # Aggregate results
        proxy_detections = [result for result in detection_results if result['is_proxy']]
        avg_confidence = np.mean([result['confidence'] for result in proxy_detections]) if proxy_detections else 0.0
        
        overall_is_proxy = len(proxy_detections) > 0 and avg_confidence > 0.5
        
        return {
            'is_proxy': overall_is_proxy,
            'confidence': avg_confidence,
            'detection_count': len(proxy_detections),
            'total_methods': len(detection_results),
            'individual_results': detection_results,
            'proxy_detections': proxy_detections,
            'recommendation': self._get_recommendation(overall_is_proxy, avg_confidence, len(proxy_detections))
        }
    
    def _calculate_distance(self, lat1: float, lng1: float, lat2: float, lng2: float) -> float:
        """Calculate distance between two GPS coordinates in kilometers"""
        from math import radians, cos, sin, asin, sqrt
        
        # Convert to radians
        lat1, lng1, lat2, lng2 = map(radians, [lat1, lng1, lat2, lng2])
        
        # Haversine formula
        dlat = lat2 - lat1
        dlng = lng2 - lng1
        a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlng/2)**2
        c = 2 * asin(sqrt(a))
        
        # Radius of earth in kilometers
        r = 6371
        return c * r
    
    def _calculate_average_time(self, times: List) -> datetime.time:
        """Calculate average time from a list of time objects"""
        total_seconds = sum(time.hour * 3600 + time.minute * 60 + time.second for time in times)
        avg_seconds = total_seconds / len(times)
        
        hours = int(avg_seconds // 3600)
        minutes = int((avg_seconds % 3600) // 60)
        seconds = int(avg_seconds % 60)
        
        return datetime.time(hours, minutes, seconds)
    
    def _time_difference_minutes(self, time1: datetime.time, time2: datetime.time) -> float:
        """Calculate difference between two times in minutes"""
        dt1 = datetime.combine(datetime.today(), time1)
        dt2 = datetime.combine(datetime.today(), time2)
        return (dt2 - dt1).total_seconds() / 60
    
    def _get_recommendation(self, is_proxy: bool, confidence: float, detection_count: int) -> str:
        """Get recommendation based on detection results"""
        if not is_proxy:
            return "No proxy detected. Attendance appears legitimate."
        
        if confidence > 0.8 and detection_count >= 2:
            return "HIGH RISK: Strong evidence of proxy attendance. Manual verification recommended."
        elif confidence > 0.6 and detection_count >= 1:
            return "MEDIUM RISK: Some evidence of proxy attendance. Additional verification suggested."
        else:
            return "LOW RISK: Weak evidence of proxy attendance. Monitor for additional patterns."
