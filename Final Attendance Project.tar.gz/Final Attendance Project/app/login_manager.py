"""
Login Manager Configuration
Handles user authentication and session management
"""

from flask_login import LoginManager, UserMixin
from app.models import User

login_manager = LoginManager()

@login_manager.user_loader
def load_user(user_id):
    """Load user from database"""
    return User.query.get(int(user_id))

@login_manager.unauthorized_handler
def unauthorized():
    """Handle unauthorized access"""
    from flask import redirect, url_for, flash
    flash('Please log in to access this page.', 'warning')
    return redirect(url_for('main.index'))
